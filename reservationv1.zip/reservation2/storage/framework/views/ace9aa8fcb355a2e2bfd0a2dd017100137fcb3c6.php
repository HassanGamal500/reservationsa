<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php elseif(session()->has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('update_doctor', $doctors[0]->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="doctor_detail_name[1]" class="form-control" placeholder="Enter Name English" value="<?php echo e($doctors[0]->name); ?>" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="doctor_detail_name[2]" class="form-control" placeholder="Enter Name Arabic" value="<?php echo e($doctors[1]->name); ?>" required>
            </div>
            <div class="form-group">
                <label>Specialization (English)</label>
                <input type="text" name="doctor_detail_specialization[1]" class="form-control" placeholder="Enter Specialization" value="<?php echo e($doctors[0]->specialization); ?>" required>
            </div>
            <div class="form-group">
                <label>Specialization (Arabic)</label>
                <input type="text" name="doctor_detail_specialization[2]" class="form-control" placeholder="Enter Specialization" value="<?php echo e($doctors[1]->specialization); ?>" required>
            </div>
            <div class="form-group">
                <label>Work Hours</label>
                <input type="text" name="doctor_work_hours" class="form-control" placeholder="Enter Work Hours" value="<?php echo e($doctors[0]->work_hour); ?>" required>
            </div>
            <div class="form-group">
                <label>Start</label>
                <input type="time" name="doctor_available_start" class="form-control" placeholder="Enter Start Date" value="<?php echo e($doctors[0]->start); ?>" required>
            </div>
            <div class="form-group">
                <label>End</label>
                <input type="time" name="doctor_available_end" class="form-control" placeholder="Enter End Date" value="<?php echo e($doctors[0]->end); ?>" required>
            </div>
            <div class="form-group">
                <label>Select Clinic</label>
                <select class="form-control" name="clinic_id">
                    <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($clinic->id); ?>" <?php echo e($doctors[0]->clinic_id == $clinic->id ? 'selected':''); ?>><?php echo e($clinic->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/clinic_doctor/edit.blade.php ENDPATH**/ ?>