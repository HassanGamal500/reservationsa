<?php

return [

    'dashboard' => 'Dashboard',
    'users' => 'Users',
    'hospitals' => 'Hospitals',
    'clinics' => 'Clinics',
    'restaurants' => 'Restaurants',
    'caterings' => 'Caterings',
    'advertisements' => 'Advertisements',
    'coupons' => 'Coupons',
    'reservations' => 'Reservations',
    'interests' => 'Interests',
    'all user' => 'All Users',
    'add user' => 'Add User',
    'all hospital' => 'All Hospitals',
    'all clinic' => 'All Clinics',
    'all restaurant' => 'All Restaurants',
    'all catering' => 'All Caterings',
    'all advertisement' => 'All Advertisements',
    'all coupon' => 'All Coupons',
    'all interest' => 'All Interests',
    'name' => 'Name',
    'phone' => 'Phone',
    'email' => 'Email',
    'image' => 'Image',
    'gender' => 'Gender',
    'actions' => 'Actions',
    'numClinic' => 'Num Of Clinics',
    'numDoctor' => 'Num Of Doctors',
    'discount' => 'Discount',

];
