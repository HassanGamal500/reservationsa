<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php elseif(session()->has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('update_clinic', $hospitals->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="clinic_name[1]" class="form-control" placeholder="Enter Name" value="<?php echo e($description_english->name); ?>">
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="clinic_name[2]" class="form-control" placeholder="Enter Name" value="<?php echo e($description_arabic->name); ?>">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="clinic_phone" class="form-control" placeholder="Enter Phone" value="<?php echo e($hospitals->phone); ?>">
            </div>
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" name="clinic_image" class="form-control-file">
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="clinic_description_part[1]" class="form-control" placeholder="Enter Description Part" value="<?php echo e($description_english->description_part); ?>">
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="clinic_description_part[2]" class="form-control" placeholder="Enter Description Part" value="<?php echo e($description_arabic->description_part); ?>">
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="clinic_description_full[1]" class="form-control" placeholder="Enter Description Full"><?php echo e($description_english->description_full); ?></textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="clinic_description_full[2]" class="form-control" placeholder="Enter Description Full"><?php echo e($description_arabic->description_full); ?></textarea>
            </div>
            <div class="form-group">
                <label>Latitude</label>
                <input type="text" name="clinic_latitude" class="form-control" placeholder="Enter Latitude" value="<?php echo e($hospitals->latitude); ?>">
            </div>
            <div class="form-group">
                <label>Longitude</label>
                <input type="text" name="clinic_longitude" class="form-control" placeholder="Enter Longitude" value="<?php echo e($hospitals->longitude); ?>">
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/hospitals/editClinic.blade.php ENDPATH**/ ?>