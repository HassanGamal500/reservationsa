<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RestaurantController extends Controller
{
    public function allRestaurants(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $restaurants = DB::table('restaurants')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
            ->where('language_id', '=', $request->language_id)
            ->select('restaurants.restaurant_id', 'restaurant_name', 'restaurant_image', 'restaurant_description_part', 'language_id')
            ->get();

        foreach($restaurants as $restaurant){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 3)
                ->where('rates.type_id', '=', $restaurant->restaurant_id)
                ->select('rate_star')
                ->avg('rate_star');
            $restaurant->rates=$rates;
            $array[]=$restaurant;
        }


        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function restaurant(Request $request) {
        $validator = validator()->make($request->all(), [
            'restaurant_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $array = array();

        $restaurants = DB::table('restaurants')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
            ->where('restaurants.restaurant_id', '=', $request->restaurant_id)
            ->where('language_id', '=', $request->language_id)
            ->select('restaurants.restaurant_id', 'restaurant_image',
                'restaurant_latitude', 'restaurant_longitude','restaurant_name',
                'restaurant_description_part', 'restaurant_description_full',
                'language_id')
            ->get();

        foreach($restaurants as $restaurant){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 3)
                ->where('rates.type_id', '=', $restaurant->restaurant_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $restaurant->rates=$rates;
            $array[]=$restaurant;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function reserveRestaurant(Request $request) {
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
            'restaurant_id' => 'required',
            'reserve_restaurant_day' => 'required',
            'reserve_restaurant_time' => 'required',
            'reserve_restaurant_num_person' => 'required',
            'reserve_restaurant_notice' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $reserve = DB::table('reserve_restaurant')->insertGetId([
            'user_id' => $request->user_id,
            'restaurant_id' => $request->restaurant_id,
            'reserve_restaurant_day' => $request->reserve_restaurant_day,
            'reserve_restaurant_time' => $request->reserve_restaurant_time,
            'reserve_restaurant_num_person' => $request->reserve_restaurant_num_person,
            'reserve_restaurant_notice' => $request->reserve_restaurant_notice,
            'status_id' => 1
        ]);
        $query = DB::table('reserve_restaurant')->where('reserve_restaurant_id', '=', $reserve)->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $query
        ];
        return response()->json($response);
    }

}
