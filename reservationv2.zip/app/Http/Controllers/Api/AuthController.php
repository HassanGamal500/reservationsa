<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use File;

class AuthController extends Controller
{
    public function register(Request $request) {
        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users',
            'password' => 'required|confirmed',
            'image' => 'required',
            'gender' => 'required'
        ]);

        if ($validator->fails()) {

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first()
            ];
            return response()->json($response);
        }

        $user = new User();

        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->gender = $request->gender;
        //$request->merge(['password' => bcrypt($request->password)]);

        $image = $request->image;  // your base64 encoded
        $end = strpos($image, ';');
        $count = $end - 11;
        $extension = substr($image, 11, $count);
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageName = time().'.'.$extension;
        File::put(public_path('images'). '/' . $imageName, base64_decode($image));
        $pathImage = 'images/'.$imageName;

        $user->api_token = Str::random(60);

        $user->image = $pathImage;

        $user->save();
        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $user
        ];
        return response()->json($response);

    }

    public function login(Request $request) {

        if (is_numeric($request->input)) {
            $validator = validator()->make($request->all(), [
                'input' => 'required',
                'password' => 'required'
            ]);

            if ($validator->fails()){

                $response = [
                    'status' => 0,
                    'message' => 'Failed',
                    'data' => 'your phone or password is not correct',
                ];
                return response()->json($response);

            }

            $user = User::where('phone', $request->input)->first();

        }


        if (filter_var($request->input, FILTER_VALIDATE_EMAIL)) {
            $validator = validator()->make($request->all(), [
                'input' => 'required|email',
                'password' => 'required'
            ]);

            if ($validator->fails()){

                $response = [
                    'status' => 0,
                    'message' => 'Failed',
                    'data' => 'your email or password is not correct',
                ];
                return response()->json($response);

            }

            $user = User::where('email', $request->input)->first();

        }

        if ($user) {

            if (Hash::check($request->password, $user->password)) {

                $response = [
                    'status' => 1,
                    'message' => 'your account is correct',
                    'data' => [
                        'User' => $user
                    ]
                ];
                return response()->json($response);

            } else {

                $response = [
                    'status' => 0,
                    'message' => 'Failed',
                    'data' => 'your password is not correct, Try Again',
                ];
                return response()->json($response);

            }

        } else {

            $response = [
                'status' => 0,
                'message' => 'Failed',
                'data' => 'your account is not correct',
            ];
            return response()->json($response);

        }

    }

    public function resetPassword(Request $request) {

        $validator = validator()->make($request->all(),[
            'email' => 'required|email',
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $user = User::where('email', $request->email)->first();

        if ($user) {

            $code = rand(1111, 9999);
            $update = $user->update(['pin_code' => $code,'is_used' => 0]);

            if ($update) {

                $to_name = 'hefny';
                $to_email = 'hefnyhefnyy@gmail.com';
                $data = array('name'=> $user->name, "body" => "Your Reset Code Is :".$code);

                Mail::send('email.mail', $data, function($message) use ($to_name, $to_email) {
                    $message->to($to_email, $to_name)
                        ->subject('Reset Password');
                    $message->from('reservation@gmail.com','Reservation');
                });

                $response = [
                    'status' => 1,
                    'message' => 'successful',
                    'data' => 'check your message on google mail'
                ];
                return response()->json($response);

            } else {
                $response = [
                    'status' => 0,
                    'message' => 'Failed',
                    'data' => 'Please Try Again'
                ];
                return response()->json($response);
            }

        } else {
            $response = [
                'status' => 0,
                'message' => 'Failed',
                'data' => 'your account is not exist'
            ];
            return response()->json($response);
        }

    }

    public function pinCode(Request $request) {
        $validator = validator()->make($request->all(),[
            'email' => 'required|email',
            'pin_code' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $user = User::where('pin_code', $request->pin_code)
            ->where('email', $request->email)
            ->first();

        if ($user){
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => $user
            ];
            return response()->json($response);
        } else {
            $response = [
                'status' => 0,
                'message' => 'Failed',
                'data' => 'This code is invalid'
            ];
            return response()->json($response);
        }
    }

    public function newPassword(Request $request) {

        $validator = validator()->make($request->all(),[
            'email' => 'required|email',
            'password' => 'required|confirmed',
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $user = User::where('email', $request->email)->first();

        if ($user) {

            $user->password = bcrypt($request->password);
            $user->is_used = 1;

            if ($user->save()) {

                $response = [
                    'status' => 1,
                    'message' => 'password changed successfully',
                    'data' => $user
                ];
                return response()->json($response);

            } else {

                $response = [
                    'status' => 0,
                    'message' => 'Failed',
                    'data' => 'something wrong, try again',
                ];
                return response()->json($response);

            }

        } else {

            $response = [
                'status' => 0,
                'message' => 'Failed',
                'data' => 'This email is invalid',
            ];
            return response()->json($response);

        }
    }

    public function profile(Request $request) {

        $id = $request->id;
        $validator= validator()->make($request->all(),[
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'gender' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }
/*
        $users = User::where('id', $id)
            ->orWhere('phone', $request->phone)
            ->orWhere('email', $request->email)
            ->first();
*/
        $user=User::find($id);
        $allPhone = User::where('phone', $request->phone)->where('id', '!=', $id)->first();
        $allEmail = User::where('email', $request->email)->where('id', '!=', $id)->first();

        if ($user){

            if ($allPhone) {
                 $response = [
                     'status' => 0,
                     'message' => 'Failed',
                     'data' => 'This phone has been taken before',
                 ];
                 return response()->json($response);
            } else {
                 $user->phone = $request->phone;
                 $user->save();
            }

            if ($allEmail) {
                $response = [
                    'status' => 0,
                    'message' => 'Failed',
                    'data' => 'This Email has been taken before',
                ];
                return response()->json($response);
            } else {
                $user->email = $request->email;
                $user->save();
            }

            if ($request->password) {

                $request->merge(['password' => bcrypt($request->password)]);

                $user->update($request->all());

            } else {

                $user->update($request->except('password'));

            }

            if ($request->gender == 0) {
                $user->gender = 'male';
                $user->save();
            } else {
                $user->gender = 'female';
                $user->save();
            }

            $user->api_token = Str::random(60);

            $user->save();

            $response = [
                'status' => 1,
                'message' => 'Updated Successfully',
                'data' => $user
            ];
            return response()->json($response);

        }else{

            $response = [
                'status' => 0,
                'message' => 'Updated Failed',
                'data' => 'Sorry, Something wrong!'
            ];
            return response()->json($response);

        }

    }

}
