@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <form method="post" action="{{route('store_advertisement')}}" enctype="multipart/form-data">
            @csrf
            @if(session()->has('error'))
                <div class="alert alert-danger" role="alert">
                    {{session()->get('error')}}
                </div>
            @elseif(session()->has('message'))
                <div class="alert alert-success" role="alert">
                    {{session()->get('message')}}
                </div>
            @endif
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="advertisement_description_name[1]" class="form-control" placeholder="Enter Name English" value="{{ old('advertisement_description_name.1') }}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="advertisement_description_name[2]" class="form-control" placeholder="Enter Name Arabic" value="{{ old('advertisement_description_name.2') }}" required>
            </div>
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" name="advertisement_image" class="form-control-file">
            </div>
            <div class="form-group">
                <label>Description Content (English)</label>
                <input type="text" name="advertisement_description_content[1]" class="form-control" placeholder="Enter Description Content" value="{{ old('advertisement_description_content.1') }}" required>
            </div>
            <div class="form-group">
                <label>Description Content (Arabic)</label>
                <input type="text" name="advertisement_description_content[2]" class="form-control" placeholder="Enter Description Content" value="{{ old('advertisement_description_content.2') }}" required>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
