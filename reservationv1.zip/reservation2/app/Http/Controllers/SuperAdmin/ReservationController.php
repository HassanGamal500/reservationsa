<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReservationController extends Controller
{
    public function index(){
        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->select('hospitals.hospital_id as id', 'hospital_name as name')
            ->where('language_id', '=', language())
            ->get();

        foreach ($hospitals as $hospital){
            $counts = DB::table('reserve_hospital')
                ->where('hospital_id', '=', $hospital->id)
                ->count();
            $hospital->counts = $counts;
            $array[] = $hospital;
        }

        return view('superAdmin.reservations.hospital', compact('array'));
    }

    public function show_hospital($id){
        $reservationHospitals = DB::table('reserve_hospital')
            ->where('hospital_id', '=', $id)
            ->get();
    }
}
