@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(session()->has('error'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('error')}}
            </div>
        @elseif(session()->has('message'))
            <div class="alert alert-success" role="alert">
                {{session()->get('message')}}
            </div>
        @endif
        <form method="post" action="{{route('update_price', $prices[0]->id)}}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="price_plan_description_name[1]" class="form-control" placeholder="Enter Name" value="{{$prices[0]->name}}">
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="price_plan_description_name[2]" class="form-control" placeholder="Enter Name" value="{{$prices[1]->name}}">
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="text" name="price" class="form-control" placeholder="Enter Price" value="{{$prices[0]->price}}">
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="price_plan_description_part[1]" class="form-control" placeholder="Enter Description Part" value="{{$prices[0]->description_part}}">
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="price_plan_description_part[2]" class="form-control" placeholder="Enter Description Part" value="{{$prices[1]->description_part}}">
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="price_plan_description_full[1]" class="form-control" placeholder="Enter Description Full">{{$prices[0]->description_full}}</textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="price_plan_description_full[2]" class="form-control" placeholder="Enter Description Full">{{$prices[1]->description_full}}</textarea>
            </div>
            <div class="form-group">
                <label>Select Catering</label>
                <select class="form-control" name="catering_id">
                    @foreach($caterings as $catering)
                        <option value="{{$catering->id}}" {{$prices[0]->catering_id == $catering->id ? 'selected':''}}>{{$catering->name}}</option>
                    @endforeach
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
