@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(session()->has('error'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('error')}}
            </div>
        @elseif(session()->has('message'))
            <div class="alert alert-success" role="alert">
                {{session()->get('message')}}
            </div>
        @endif
        <form method="post" action="{{route('update_interest', $interests[1]->interest_id)}}">
            @csrf
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="interest_name[1]" class="form-control" placeholder="Enter Name" value="{{$interests[0]->interest_name}}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="interest_name[2]" class="form-control" placeholder="Enter Name" value="{{$interests[1]->interest_name}}" required>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
