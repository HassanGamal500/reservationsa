<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class InterestController extends Controller
{
    public function index(){
        $interests = DB::table('interests')
            ->join('interest_description', 'interest_description.interest_id', '=', 'interests.interest_id')
            ->select('interests.interest_id as id', 'interest_name as name')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.interests.index', compact('interests'));
    }

    public function create(){
        return view('superAdmin.interests.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'interest_name' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        $interests = DB::table('interests')
//            ->increment('interest_id')
            ->insertGetId(['interest_id' => null]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('interest_description')
                ->insert([
                    'interest_name' => $request->interest_name[$i],
                    'language_id' => $i,
                    'interest_id' => $interests
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $interests = DB::table('interests')
            ->join('interest_description', 'interest_description.interest_id', '=', 'interests.interest_id')
            ->select('interests.interest_id', 'interest_name')
            ->where('interests.interest_id', '=', $id)
            ->get();
        return view('superAdmin.interests.edit', compact('interests'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'interest_name' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('interest_description')
                ->where('interest_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'interest_name' => $request->interest_name[$i],
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $interests = DB::table('interests')
            ->where('interest_id', '=', $id)
            ->delete();
        return 1;
    }
}
