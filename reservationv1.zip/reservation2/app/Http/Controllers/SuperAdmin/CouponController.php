<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class CouponController extends Controller
{
    public function index(){
        $coupons = DB::table('coupons')
            ->select('coupon_id as id', 'coupon_name as name', 'coupon_discount as discount')
            ->get();
        return view('superAdmin.coupons.index', compact('coupons'));
    }

    public function create(){
        return view('superAdmin.coupons.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'coupon_name' => 'required',
            'coupon_discount' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        $coupon = DB::table('coupons')
            ->insert([
                'coupon_name' => $request->coupon_name,
                'coupon_discount' => $request->coupon_discount
            ]);

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $coupons = DB::table('coupons')
            ->select('coupon_id as id', 'coupon_name as name', 'coupon_discount as discount')
            ->where('coupon_id', '=', $id)
            ->first();

        return view('superAdmin.coupons.edit', compact('coupons'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'coupon_name' => 'required',
            'coupon_discount' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        $coupons = DB::table('coupons')
            ->where('coupon_id', '=', $id)
            ->update([
                'coupon_name' => $request->coupon_name,
                'coupon_discount' => $request->coupon_discount
            ]);

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $caterings = DB::table('coupons')
            ->where('coupon_id', '=', $id)
            ->delete();
        return 1;
    }
}
