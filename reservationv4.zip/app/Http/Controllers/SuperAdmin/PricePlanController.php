<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class PricePlanController extends Controller
{
    public function index(){
        $prices = DB::table('catering')
            ->join('price_plan', 'price_plan.catering_id', '=', 'catering.catering_id')
            ->join('price_plan_description', 'price_plan_description.price_plan_id', '=', 'price_plan.price_plan_id')
            ->select('price_plan.price_plan_id as id', 'price', 'price_plan_description_name as name',
                'price_plan_description_part as description_part', 'price_plan_description_full as description_full')
            ->where('language_id', '=', language())
            ->orderBy('price_plan.price_plan_id', 'desc')
            ->get();
        return view('superAdmin.prices.index', compact('prices'));
    }

    public function show($id){
        $prices = DB::table('catering')
            ->join('price_plan', 'price_plan.catering_id', '=', 'catering.catering_id')
            ->join('price_plan_description', 'price_plan_description.price_plan_id', '=', 'price_plan.price_plan_id')
            ->select('price_plan.price_plan_id as id', 'price', 'price_plan_description_name as name',
                'price_plan_description_part as description_part', 'price_plan_description_full as description_full')
            ->where('language_id', '=', language())
            ->where('catering.catering_id', '=', $id)
            ->orderBy('price_plan.price_plan_id', 'desc')
            ->get();
        return view('superAdmin.prices.index', compact('prices'));
    }

    public function create(){
        $caterings = DB::table('catering')
            ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
            ->select('catering.catering_id as id', 'catering_name as name')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.prices.create', compact('caterings'));
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'price_plan_description_name' => 'required',
            'price' => 'required',
            'price_plan_description_part' => 'required',
            'price_plan_description_full' => 'required',
            'catering_id' => 'required'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        $prices = DB::table('price_plan')
            ->insertGetId([
                'price' => $request->price,
                'catering_id' => $request->catering_id
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('price_plan_description')
                ->insert([
                    'price_plan_description_name' => $request->price_plan_description_name[$i],
                    'price_plan_description_part' => $request->price_plan_description_part[$i],
                    'price_plan_description_full' => $request->price_plan_description_full[$i],
                    'language_id' => $i,
                    'price_plan_id' => $prices
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $caterings = DB::table('catering')
            ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
            ->select('catering.catering_id as id', 'catering_name as name')
            ->where('language_id', '=', language())
            ->get();

        $prices = DB::table('price_plan')
            ->join('price_plan_description','price_plan_description.price_plan_id', '=', 'price_plan.price_plan_id')
            ->select('price_plan.price_plan_id as id', 'price', 'catering_id',
                'price_plan_description_name as name', 'price_plan_description_part as description_part',
                'price_plan_description_full as description_full')
            ->where('price_plan.price_plan_id', '=', $id)
            ->get();

        return view('superAdmin.prices.edit', compact('prices','caterings'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'price_plan_description_name' => 'required',
            'price' => 'required',
            'price_plan_description_part' => 'required',
            'price_plan_description_full' => 'required',
            'catering_id' => 'required'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        $prices = DB::table('price_plan')
            ->where('price_plan_id', '=', $id)
            ->update([
                'price' => $request->price,
                'catering_id' => $request->catering_id
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('price_plan_description')
                ->where('price_plan_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'price_plan_description_name' => $request->price_plan_description_name[$i],
                    'price_plan_description_part' => $request->price_plan_description_part[$i],
                    'price_plan_description_full' => $request->price_plan_description_full[$i]
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $hospitals = DB::table('price_plan')
            ->where('price_plan_id', '=', $id)
            ->delete();
        return 1;
    }
}
