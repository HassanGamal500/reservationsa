<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AppController extends Controller
{
    public function advertisements(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $ad = DB::table('advertisements')
            ->join('advertisement_description', 'advertisement_description.advertisement_id', '=', 'advertisements.advertisement_id')
            ->select('advertisements.advertisement_id', 'advertisement_image', 'advertisement_description_name', 'advertisement_description_content')
            ->orderBy('advertisements.advertisement_id', 'DESC')
            ->where('language_id', '=', $request->language_id)
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $ad
        ];

        return response()->json($response);
    }

    public function histories(Request $request) {
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $reserveHospitals = DB::table('reserve_hospital')
            ->where('user_id', '=', $request->user_id)
            ->select('reserve_hospital_id', 'reserve_hospital_notice')
            ->get();

        $reserveClinics = DB::table('reserve_clinic')
            ->where('user_id', '=', $request->user_id)
            ->select('reserve_clinic_id', 'reserve_clinic_notice')
            ->get();

        $reserveRestaurants = DB::table('reserve_restaurant')
            ->where('user_id', '=', $request->user_id)
            ->select('reserve_restaurant_id', 'reserve_restaurant_notice')
            ->get();

        $reserveCaterings = DB::table('reserve_catering')
            ->where('user_id', '=', $request->user_id)
            ->select('reserve_catering_id', 'reserve_catering_notice')
            ->get();

        foreach ($reserveHospitals as $hospital){
            $hospital->type = 1;
            $array[] = $hospital;
        }
        foreach ($reserveClinics as $clinic){
            $clinic->type = 2;
            $array[] = $clinic;
        }
        foreach ($reserveRestaurants as $restaurant){
            $restaurant->type = 3;
            $array[] = $restaurant;
        }
        foreach ($reserveCaterings as $catering){
            $catering->type = 4;
            $array[] = $catering;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];
        return response()->json($response);
    }

    public function notifications(Request $request){
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $array = array();
        $notifications = DB::table('notifications')->where('user_id', '=', $request->user_id)->get();
        foreach ($notifications as $notification){
            if ($notification->type == 1) {
                $content = 'hospital hospital hospital hospital ';
                $gets = DB::table('hospitals')
                    ->where('hospitals.hospital_id', '=', $notification->type_id)
                    ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
                    ->where('language_id', '=', $request->language_id)
                    ->select('hospital_name as name', 'hospital_image as image')
                    ->get();

                foreach($gets as $get){
                    $get->content = $content;
                    $array[]=$get;
                }
            } elseif($notification->type == 2) {
                $content = 'clinic clinic clinic clinic clinic ';
                $gets = DB::table('clinics')
                    ->where('clinics.clinic_id', '=', $notification->type_id)
                    ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
                    ->where('language_id', '=', $request->language_id)
                    ->select('clinic_name as name', 'clinic_image as image')
                    ->get();
                foreach($gets as $get){
                    $get->content = $content;
                    $array[]=$get;
                }
            } elseif($notification->type == 3) {
                $content = 'restaurant restaurant restaurant restaurant ';
                $gets = DB::table('restaurants')
                    ->where('restaurants.restaurant_id', '=', $notification->type_id)
                    ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
                    ->where('language_id', '=', $request->language_id)
                    ->select('restaurant_name as name', 'restaurant_image as image')
                    ->get();
                foreach($gets as $get){
                    $get->content = $content;
                    $array[]=$get;
                }
            } elseif($notification->type == 4) {
                $content = 'catering catering catering catering ';
                $gets = DB::table('catering')
                    ->where('catering.catering_id', '=', $notification->type_id)
                    ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
                    ->where('language_id', '=', $request->language_id)
                    ->select('catering_name as name', 'catering_image as image')
                    ->get();
                foreach($gets as $get){
                    $get->content = $content;
                    $array[]=$get;
                }
            } else {
                if ($request->language_id == 1) {
                    $array[] = [
                        'name' => 'Administrator',
                        'image' => '/images/1570432357.png',
                        'content' => 'admin admin admin admin admin admin '
                    ];
                } else {
                    $array[] = [
                        'name' => 'الاداره',
                        'image' => '/images/1570432357.png',
                        'content' => 'الادمن الادمن الادمن الادمن الادمن الادمن '
                    ];
                }
            }
        }

        if (!empty($array)){
            $response = [
                'status' => 1,
                'message' => 'Successful',
                'data' => $array
            ];
        } else {
            $response = [
                'status' => 0,
                'message' => 'Failed',
                'data' => 'the user do not have notification'
            ];
        }

        return response()->json($response);

    }

    public function images(Request $request){
        $validator = validator()->make($request->all(), [
            'type' => 'required',
            'type_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $images = DB::table('images')
            ->where('type', '=', $request->type)
            ->where('type_id', '=', $request->type_id)
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $images
        ];

        return response()->json($response);
    }

    public function interests(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required',
            'user_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $interests = DB::table('interests')
            ->join('interest_description', 'interest_description.interest_id', '=', 'interests.interest_id')
            ->where('interest_description.language_id', '=', $request->language_id)
            ->get();

        $user_interest = DB::table('interests')
            ->join('interest_description', 'interest_description.interest_id', '=', 'interests.interest_id')
            ->join('user_interest', 'user_interest.interest_id', '=', 'interests.interest_id')
            ->where('interest_description.language_id', '=', $request->language_id)
            ->where('user_interest.user_id', '=', $request->user_id)
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => [
                'interests' => $interests,
                'user_interest' => $user_interest
                ]
        ];

        return response()->json($response);
    }


}
