<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Super Admin

use Illuminate\Support\Facades\App;

Route::get('/lang/{locale}', function ($locale){
    App::setLocale($locale);
    session()->put('locale', $locale);
    return redirect()->back();
});

Route::get('/', function (){
    return view('welcome');
});

Route::get('check', function (){
    dd(auth()->guard('admin')->user()->name);
});

Route::get('/admin/login', 'SuperAdmin\AdminLoginController@showLoginForm')->name('admin.login');
Route::post('/admin/login', 'SuperAdmin\AdminLoginController@login')->name('admin.login.post');
Route::post('/admin/logout', 'SuperAdmin\AdminLoginController@logout')->name('admin.logout');

Route::group(['prefix' => 'admin','namespace' => 'SuperAdmin', 'middleware' => 'admin'], function (){
    // Users
    Route::get('/', 'DashboardController@index');
    Route::get('/users', 'UserController@index')->name('all_users');
    Route::get('/add_user', 'UserController@create');
    Route::post('/add_user', 'UserController@store')->name('store_user');
    Route::get('/edit_user/{id}', 'UserController@edit')->name('edit_user');
    Route::post('/edit_user/{id}', 'UserController@update')->name('update_user');
    Route::delete('/delete_user/{id}', 'UserController@destroy')->name('delete_user');
    // Hospitals
    Route::get('hospitals', 'HospitalController@index');
    Route::get('/add_hospital', 'HospitalController@create');
    Route::post('/add_hospital', 'HospitalController@store')->name('store_hospital');
    Route::get('/edit_hospital/{id}', 'HospitalController@edit')->name('edit_hospital');
    Route::post('/edit_hospital/{id}', 'HospitalController@update')->name('update_hospital');
    Route::delete('/delete_hospital/{id}', 'HospitalController@destroy')->name('delete_hospital');
    // Hospital Clinic
    Route::get('clinic_hospital', 'HospitalClinicController@index');
    Route::get('clinic_hospital/{id}', 'HospitalClinicController@show')->name('show_clinic');
    Route::get('/add_clinic_hospital', 'HospitalClinicController@create');
    Route::post('/add_clinic_hospital', 'HospitalClinicController@store')->name('store_clinic_hospital');
    Route::get('/edit_clinic_hospital/{id}', 'HospitalClinicController@edit')->name('edit_clinic_hospital');
    Route::post('/edit_clinic_hospital/{id}', 'HospitalClinicController@update')->name('update_clinic_hospital');
    Route::delete('/delete_clinic_hospital/{id}', 'HospitalClinicController@destroy')->name('delete_clinic_hospital');
    // Hospital Clinic Doctor
    Route::get('clinic_doctor', 'ClinicDoctorController@index');
    Route::get('clinic_doctor/{id}', 'ClinicDoctorController@show')->name('show_doctor');
    Route::get('/add_doctor', 'ClinicDoctorController@create');
    Route::post('/add_doctor', 'ClinicDoctorController@store')->name('store_doctor');
    Route::get('/edit_doctor/{id}', 'ClinicDoctorController@edit')->name('edit_doctor');
    Route::post('/edit_doctor/{id}', 'ClinicDoctorController@update')->name('update_doctor');
    Route::delete('/delete_doctor/{id}', 'ClinicDoctorController@destroy')->name('delete_doctor');
    // Clinics
    Route::get('clinics', 'ClinicController@index');
    Route::get('clinics/{id}', 'ClinicController@show')->name('show_doctor_c');
    Route::get('/add_clinic', 'ClinicController@create');
    Route::post('/add_clinic', 'ClinicController@store')->name('store_clinic');
    Route::get('/edit_clinic/{id}', 'ClinicController@edit')->name('edit_clinic');
    Route::post('/edit_clinic/{id}', 'ClinicController@update')->name('update_clinic');
    Route::delete('/delete_clinic/{id}', 'ClinicController@destroy')->name('delete_clinic');
    // Clinic Doctor
    Route::get('all_doctor', 'ClinicDoctorController@index');
    Route::get('/add_doctor_clinic', 'ClinicDoctorController@create');
    Route::post('/add_doctor_clinic', 'ClinicDoctorController@store')->name('store_doctor');
    Route::get('/edit_doctor_clinic/{id}', 'ClinicDoctorController@edit')->name('edit_doctor');
    Route::post('/edit_doctor_clinic/{id}', 'ClinicDoctorController@update')->name('update_doctor');
    Route::delete('/delete_doctor_clinic/{id}', 'ClinicDoctorController@destroy')->name('delete_doctor');
    // Restaurants
    Route::get('restaurants', 'RestaurantController@index');
    Route::get('/add_restaurant', 'RestaurantController@create');
    Route::post('/add_restaurant', 'RestaurantController@store')->name('store_restaurant');
    Route::get('/edit_restaurant/{id}', 'RestaurantController@edit')->name('edit_restaurant');
    Route::post('/edit_restaurant/{id}', 'RestaurantController@update')->name('update_restaurant');
    Route::delete('/delete_restaurant/{id}', 'RestaurantController@destroy')->name('delete_restaurant');
    // Caterings
    Route::get('caterings', 'CateringController@index');
    Route::get('/add_catering', 'CateringController@create');
    Route::post('/add_catering', 'CateringController@store')->name('store_catering');
    Route::get('/edit_catering/{id}', 'CateringController@edit')->name('edit_catering');
    Route::post('/edit_catering/{id}', 'CateringController@update')->name('update_catering');
    Route::delete('/delete_catering/{id}', 'CateringController@destroy')->name('delete_catering');
    // Catering Prince Plan
    Route::get('prices', 'PricePlanController@index');
    Route::get('prices/{id}', 'PricePlanController@show')->name('show_price');
    Route::get('/add_price', 'PricePlanController@create');
    Route::post('/add_price', 'PricePlanController@store')->name('store_price');
    Route::get('/edit_price/{id}', 'PricePlanController@edit')->name('edit_price');
    Route::post('/edit_price/{id}', 'PricePlanController@update')->name('update_price');
    Route::delete('/delete_price/{id}', 'PricePlanController@destroy')->name('delete_price');
    // Advertisements
    Route::get('advertisements', 'AdvertisementController@index');
    Route::get('/add_advertisement', 'AdvertisementController@create');
    Route::post('/add_advertisement', 'AdvertisementController@store')->name('store_advertisement');
    Route::get('/edit_advertisement/{id}', 'AdvertisementController@edit')->name('edit_advertisement');
    Route::post('/edit_advertisement/{id}', 'AdvertisementController@update')->name('update_advertisement');
    Route::delete('/delete_advertisement/{id}', 'AdvertisementController@destroy')->name('delete_advertisement');
    // Coupons
    Route::get('coupons', 'CouponController@index');
    Route::get('/add_coupon', 'CouponController@create');
    Route::post('/add_coupon', 'CouponController@store')->name('store_coupon');
    Route::get('/edit_coupon/{id}', 'CouponController@edit')->name('edit_coupon');
    Route::post('/edit_coupon/{id}', 'CouponController@update')->name('update_coupon');
    Route::delete('/delete_coupon/{id}', 'CouponController@destroy')->name('delete_coupon');
    // Interests
    Route::get('interests', 'InterestController@index');
    Route::get('/add_interest', 'InterestController@create');
    Route::post('/add_interest', 'InterestController@store')->name('store_interest');
    Route::get('/edit_interest/{id}', 'InterestController@edit')->name('edit_interest');
    Route::post('/edit_interest/{id}', 'InterestController@update')->name('update_interest');
    Route::delete('/delete_interest/{id}', 'InterestController@destroy')->name('delete_interest');
    // Reservations
    Route::get('reserve_hospital/{id}', 'ReservationController@hospital')->name('hospital_reserve');
    Route::get('reserve_clinic/{id}', 'ReservationController@clinic')->name('clinic_reserve');
    Route::get('reserve_restaurant/{id}', 'ReservationController@restaurant')->name('restaurant_reserve');
    Route::get('reserve_catering/{id}', 'ReservationController@catering')->name('catering_reserve');
    Route::get('show_reserve_hospital/{id}', 'ReservationController@showReserveHospital')->name('hospital_show');
    Route::get('show_reserve_clinic/{id}', 'ReservationController@showReserveClinic')->name('clinic_show');
    Route::get('show_reserve_restaurant/{id}', 'ReservationController@showReserveRestaurant')->name('restaurant_show');
    Route::get('show_reserve_catering/{id}', 'ReservationController@showReserveCatering')->name('catering_show');
    // Admin User
    Route::get('/edit_profile/{id}', 'AdminLoginController@editProfile')->name('edit_profile');
    Route::post('/edit_profile/{id}', 'AdminLoginController@updateProfile')->name('update_profile');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
