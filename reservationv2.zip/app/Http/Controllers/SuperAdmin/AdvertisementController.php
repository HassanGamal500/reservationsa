<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class AdvertisementController extends Controller
{
    public function index(){
        $ads = DB::table('advertisements')
            ->join('advertisement_description', 'advertisement_description.advertisement_id', '=', 'advertisements.advertisement_id')
            ->select('advertisements.advertisement_id as id', 'advertisements.advertisement_image as image', 'advertisement_description_name as name',
                'advertisement_description_content as description_content')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.advertisements.index', compact('ads'));
    }

    public function create(){
        return view('superAdmin.advertisements.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'advertisement_description_name' => 'required',
            'advertisement_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'advertisement_description_content' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

//        if ($request->hasFile('advertisement_image')) {
//            $imageName = 'images/advertisement/'.time().'.'.$request->advertisement_image->getClientOriginalExtension();
//            $request->advertisement_image->move(public_path('images/advertisement'), $imageName);
//        } else {
//            $imageName = 'images/advertisement/avatar_advertisement.png';
//        }

        $advertisement = DB::table('advertisements')->insertGetId(['advertisement_image' => 'images/advertisement/avatar_advertisement.png']);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('advertisement_description')
                ->insert([
                    'advertisement_description_name' => $request->advertisement_description_name[$i],
                    'advertisement_description_content' => $request->advertisement_description_content[$i],
                    'language_id' => $i,
                    'advertisement_id' => $advertisement
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $advertisements = DB::table('advertisements')
            ->join('advertisement_description', 'advertisement_description.advertisement_id', '=', 'advertisements.advertisement_id')
            ->select('advertisements.advertisement_id as id', 'advertisement_image as image', 'advertisement_description_name as name', 'advertisement_description_content as description_content')
            ->where('advertisements.advertisement_id', '=', $id)
            ->get();
        return view('superAdmin.advertisements.edit', compact('advertisements'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'advertisement_description_name' => 'required',
            'advertisement_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'advertisement_description_content' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

//        if ($request->hasFile('advertisement_image')) {
//            $imageName = 'images/advertisement/'.time().'.'.$request->advertisement_image->getClientOriginalExtension();
//            $request->advertisement_image->move(public_path('images/advertisement'), $imageName);
//        } else {
//            $imageName = 'images/advertisement/avatar_advertisement.png';
//        }

        $advertisements = DB::table('advertisements')
            ->where('advertisement_id', '=', $id)
            ->update(['advertisement_image' => 'images/advertisement/avatar_advertisement.png']);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('advertisement_description')
                ->where('advertisement_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'advertisement_description_name' => $request->advertisement_description_name[$i],
                    'advertisement_description_content' => $request->advertisement_description_content[$i],
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $caterings = DB::table('advertisements')
            ->where('advertisement_id', '=', $id)
            ->delete();
        return 1;
    }
}
