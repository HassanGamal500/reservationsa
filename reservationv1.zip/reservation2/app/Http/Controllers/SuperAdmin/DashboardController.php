<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(){
        $users = DB::table('users')->count();
        $hospitals = DB::table('hospitals')->count();
        $clinics = DB::table('clinics')->count();
        $doctors = DB::table('doctors')->count();
        $restaurants = DB::table('restaurants')->count();
        $caterings = DB::table('catering')->count();
        $ad = DB::table('advertisements')->count();
        $coupons = DB::table('coupons')->count();
        $reserveHospitals = DB::table('reserve_hospital')->count();
        $reserveClinics = DB::table('reserve_clinic')->count();
        $reserveRestaurants = DB::table('reserve_restaurant')->count();
        $reserveCaterings = DB::table('reserve_catering')->count();
        $reservations = $reserveHospitals + $reserveClinics + $reserveRestaurants + $reserveCaterings;
        return view('superAdmin.dashboard')->with([
            'users' => $users,
            'hospitals' => $hospitals,
            'clinics' => $clinics,
            'doctors' => $doctors,
            'reservations' => $reservations,
            'restaurants' => $restaurants,
            'caterings' => $caterings,
            'ad' => $ad,
            'coupons' => $coupons]);
    }
}
