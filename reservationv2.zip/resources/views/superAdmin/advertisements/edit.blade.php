@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(session()->has('error'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('error')}}
            </div>
        @elseif(session()->has('message'))
            <div class="alert alert-success" role="alert">
                {{session()->get('message')}}
            </div>
        @endif
        <form method="post" action="{{route('update_advertisement', $advertisements[0]->id)}}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="advertisement_description_name[1]" class="form-control" placeholder="Enter Name" value="{{$advertisements[0]->name}}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="advertisement_description_name[2]" class="form-control" placeholder="Enter Name" value="{{$advertisements[1]->name}}" required>
            </div>
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" name="advertisement_image" class="form-control-file" required>
            </div>
            <div class="form-group">
                <label>Description Content (English)</label>
                <textarea type="text" name="advertisement_description_content[1]" class="form-control" placeholder="Enter Description Full" required>{{$advertisements[0]->description_content}}</textarea>
            </div>
            <div class="form-group">
                <label>Description Content (Arabic)</label>
                <textarea type="text" name="advertisement_description_content[2]" class="form-control" placeholder="Enter Description Full" required>{{$advertisements[1]->description_content}}</textarea>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
