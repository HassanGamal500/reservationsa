<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class RestaurantController extends Controller
{
    public function index(){
        $restaurants = DB::table('restaurants')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
            ->select('restaurants.restaurant_id as id', 'restaurant_name as name',
                'restaurant_image as image', 'restaurant_latitude as latitude', 'restaurant_longitude as longitude',
                'restaurant_description_part as description_part', 'restaurant_description_full as description_full')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.restaurants.index', compact('restaurants'));
    }

    public function create(){
        return view('superAdmin.restaurants.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'restaurant_name' => 'required',
            'restaurant_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'restaurant_description_part' => 'required',
            'restaurant_description_full' => 'required',
            'restaurant_latitude' => 'required',
            'restaurant_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

//        if ($request->hasFile('restaurant_image')) {
//            $imageName = 'images/restaurant/'.time().'.'.$request->restaurant_image->getClientOriginalExtension();
//            $request->restaurant_image->move(public_path('images/restaurant'), $imageName);
//        } else {
//            $imageName = 'images/restaurant/avatar_restaurant.png';
//        }

        $restaurants = DB::table('restaurants')
            ->insertGetId([
                'restaurant_image' => 'images/restaurant/avatar_restaurant.png',
                'restaurant_latitude' => $request->restaurant_latitude,
                'restaurant_longitude' => $request->restaurant_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('restaurant_description')
                ->insert([
                    'restaurant_name' => $request->restaurant_name[$i],
                    'restaurant_description_part' => $request->restaurant_description_part[$i],
                    'restaurant_description_full' => $request->restaurant_description_full[$i],
                    'language_id' => $i,
                    'restaurant_id' => $restaurants
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $restaurants = DB::table('restaurants')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
            ->select('restaurants.restaurant_id as id', 'restaurant_image as image',
                'restaurant_latitude as latitude', 'restaurant_longitude as longitude',
                'restaurant_name as name', 'restaurant_description_part as description_part',
                'restaurant_description_full as description_full')
            ->where('restaurants.restaurant_id', '=', $id)
            ->get();

        return view('superAdmin.restaurants.edit', compact('restaurants'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'restaurant_name' => 'required',
            'restaurant_image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'restaurant_description_part' => 'required',
            'restaurant_description_full' => 'required',
            'restaurant_latitude' => 'required',
            'restaurant_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

//        if ($request->hasFile('restaurant_image')) {
//            $imageName = 'images/restaurant/'.time().'.'.$request->restaurant_image->getClientOriginalExtension();
//            $request->restaurant_image->move(public_path('images/restaurant'), $imageName);
//        } else {
//            $imageName = 'images/restaurant/avatar_restaurant.png';
//        }

        $restaurants = DB::table('restaurants')
            ->where('restaurant_id', '=', $id)
            ->update([
                'restaurant_image' => 'images/restaurant/avatar_restaurant.png',
                'restaurant_latitude' => $request->restaurant_latitude,
                'restaurant_longitude' => $request->restaurant_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('restaurant_description')
                ->where('restaurant_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'restaurant_name' => $request->restaurant_name[$i],
                    'restaurant_description_part' => $request->restaurant_description_part[$i],
                    'restaurant_description_full' => $request->restaurant_description_full[$i],
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $hospitals = DB::table('restaurants')
            ->where('restaurant_id', '=', $id)
            ->delete();
        return 1;
    }
}
