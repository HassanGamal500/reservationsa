@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <form method="post" action="{{route('store_doctor')}}" enctype="multipart/form-data">
            @csrf
            @if(session()->has('error'))
                <div class="alert alert-danger" role="alert">
                    {{session()->get('error')}}
                </div>
            @elseif(session()->has('message'))
                <div class="alert alert-success" role="alert">
                    {{session()->get('message')}}
                </div>
            @endif
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="doctor_detail_name[1]" class="form-control" placeholder="Enter Name English" value="{{ old('doctor_detail_name.1') }}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="doctor_detail_name[2]" class="form-control" placeholder="Enter Name Arabic" value="{{ old('doctor_detail_name.2') }}" required>
            </div>
            <div class="form-group">
                <label>Specialization (English)</label>
                <input type="text" name="doctor_detail_specialization[1]" class="form-control" placeholder="Enter Specialization" value="{{ old('doctor_detail_specialization.1') }}" required>
            </div>
            <div class="form-group">
                <label>Specialization (Arabic)</label>
                <input type="text" name="doctor_detail_specialization[2]" class="form-control" placeholder="Enter Specialization" value="{{ old('doctor_detail_specialization.2') }}" required>
            </div>
            <div class="form-group">
                <label>Work Hours</label>
                <input type="text" name="doctor_work_hours" class="form-control" placeholder="Enter Work Hours" value="{{ old('doctor_work_hours') }}" required>
            </div>
            <div class="form-group">
                <label>Start</label>
                <input type="time" name="doctor_available_start" class="form-control" placeholder="Enter Start Date" value="{{ old('doctor_available_start') }}" required>
            </div>
            <div class="form-group">
                <label>End</label>
                <input type="time" name="doctor_available_end" class="form-control" placeholder="Enter End Date" value="{{ old('doctor_available_end') }}" required>
            </div>
            <div class="form-group">
                <label>Select Clinic</label>
                <select class="form-control" name="clinic_id">
                    @foreach($clinics as $clinic)
                        <option value="{{$clinic->id}}">{{$clinic->name}}</option>
                    @endforeach
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
