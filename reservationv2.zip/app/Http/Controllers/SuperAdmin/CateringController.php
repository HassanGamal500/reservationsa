<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class CateringController extends Controller
{
    public function index(){
        $caterings = DB::table('catering')
            ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
            ->select('catering.catering_id as id', 'catering_name as name',
                'catering_image as image', 'catering_latitude as latitude', 'catering_longitude as longitude',
                'catering_description_part as description_part', 'catering_description_full as description_full')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.caterings.index', compact('caterings'));
    }

    public function create(){
        return view('superAdmin.caterings.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'catering_name' => 'required',
            'catering_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'catering_description_part' => 'required',
            'catering_description_full' => 'required',
            'catering_latitude' => 'required',
            'catering_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

//        if ($request->hasFile('catering_image')) {
//            $imageName = 'images/catering/'.time().'.'.$request->catering_image->getClientOriginalExtension();
//            $request->catering_image->move(public_path('images/catering'), $imageName);
//        } else {
//            $imageName = 'images/catering/avatar_catering.jpg';
//        }

        $catering = DB::table('catering')
            ->insertGetId([
                'catering_image' => 'images/restaurant/avatar_restaurant.png',
                'catering_latitude' => $request->catering_latitude,
                'catering_longitude' => $request->catering_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('catering_description')
                ->insert([
                    'catering_name' => $request->catering_name[$i],
                    'catering_description_part' => $request->catering_description_part[$i],
                    'catering_description_full' => $request->catering_description_full[$i],
                    'language_id' => $i,
                    'catering_id' => $catering
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $caterings = DB::table('catering')
            ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
            ->select('catering.catering_id as id', 'catering_image as image',
                'catering_latitude as latitude', 'catering_longitude as longitude',
                'catering_name as name', 'catering_description_part as description_part',
                'catering_description_full as description_full')
            ->where('catering.catering_id', '=', $id)
            ->get();

        return view('superAdmin.caterings.edit', compact('caterings'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'catering_name' => 'required',
            'catering_image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'catering_description_part' => 'required',
            'catering_description_full' => 'required',
            'catering_latitude' => 'required',
            'catering_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

//        if ($request->hasFile('catering_image')) {
//            $imageName = 'images/catering/'.time().'.'.$request->catering_image->getClientOriginalExtension();
//            $request->catering_image->move(public_path('images/catering'), $imageName);
//        } else {
//            $imageName = 'images/catering/avatar_catering.jpg';
//        }

        $caterings = DB::table('catering')
            ->where('catering_id', '=', $id)
            ->update([
                'catering_image' => 'images/catering/avatar_catering.jpg',
                'catering_latitude' => $request->catering_latitude,
                'catering_longitude' => $request->catering_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('catering_description')
                ->where('catering_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'catering_name' => $request->catering_name[$i],
                    'catering_description_part' => $request->catering_description_part[$i],
                    'catering_description_full' => $request->catering_description_full[$i],
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $caterings = DB::table('catering')
            ->where('catering_id', '=', $id)
            ->delete();
        return 1;
    }
}
