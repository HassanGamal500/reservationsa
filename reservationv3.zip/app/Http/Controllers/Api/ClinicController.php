<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClinicController extends Controller
{
    public function allClinics(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->where('language_id', '=', $request->language_id)
            ->select('clinics.clinic_id', 'clinic_name', 'clinic_image', 'clinic_description_part', 'language_id')
            ->get();

        foreach($clinics as $clinic){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 2)
                ->where('rates.type_id', '=', $clinic->clinic_id)
                ->select('rate_star')
                ->avg('rate_star');
            $clinic->rates=$rates;
            $array[]=$clinic;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function clinic(Request $request) {
        $validator = validator()->make($request->all(), [
            'clinic_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $array = array();

        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->where('clinics.clinic_id', '=', $request->clinic_id)
            ->where('language_id', '=', $request->language_id)
            ->select('clinics.clinic_id', 'clinic_image',
                'clinic_latitude', 'clinic_longitude','clinic_name',
                'clinic_description_part', 'clinic_description_full',
                'language_id')
            ->get();

        foreach($clinics as $clinic){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 2)
                ->where('rates.type_id', '=', $clinic->clinic_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $clinic->rates=$rates;
            $array[]=$clinic;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function reserveClinic(Request $request) {
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
            'clinic_id' => 'required',
            'doctor_id' => 'required',
            'reserve_clinic_day' => 'required',
            'reserve_clinic_time' => 'required',
            'reserve_clinic_is_insurance' => 'required',
            'reserve_clinic_payment_id' => 'required',
            'reserve_clinic_has_file' => 'required',
            'reserve_clinic_notice' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $reserve = DB::table('reserve_clinic')->insertGetId($request->all());
        $query = DB::table('reserve_clinic')->where('reserve_clinic_id', '=', $reserve)->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $query
        ];
        return response()->json($response);
    }

}
