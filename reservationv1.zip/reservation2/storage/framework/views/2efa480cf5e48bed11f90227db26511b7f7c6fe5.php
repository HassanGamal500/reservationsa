<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <form method="post" action="<?php echo e(route('store_restaurant')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php elseif(session()->has('message')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="restaurant_name[1]" class="form-control" placeholder="Enter Name English" value="<?php echo e(old('restaurant_name.1')); ?>" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="restaurant_name[2]" class="form-control" placeholder="Enter Name Arabic" value="<?php echo e(old('restaurant_name.2')); ?>" required>
            </div>
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" name="restaurant_image" class="form-control-file">
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="restaurant_description_part[1]" class="form-control" placeholder="Enter Description Part" value="<?php echo e(old('restaurant_description_part.1')); ?>" required>
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="restaurant_description_part[2]" class="form-control" placeholder="Enter Description Part" value="<?php echo e(old('restaurant_description_part.2')); ?>" required>
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="restaurant_description_full[1]" class="form-control" placeholder="Enter Description Full" required><?php echo e(old('restaurant_description_full.1')); ?></textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="restaurant_description_full[2]" class="form-control" placeholder="Enter Description Full" required><?php echo e(old('restaurant_description_full.2')); ?></textarea>
            </div>
            <div class="form-group">
                <label>Latitude</label>
                <input type="text" name="restaurant_latitude" class="form-control" placeholder="Enter Latitude" value="<?php echo e(old('restaurant_latitude')); ?>" required>
            </div>
            <div class="form-group">
                <label>Longitude</label>
                <input type="text" name="restaurant_longitude" class="form-control" placeholder="Enter Longitude" value="<?php echo e(old('restaurant_longitude')); ?>" required>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/restaurants/create.blade.php ENDPATH**/ ?>