<?php

return [

    'dashboard' => 'لوحة التحكم الرئيسية',
    'users' => 'المستخدمين',
    'hospitals' => 'المستشفيات',
    'clinics' => 'العيادات',
    'restaurants' => 'المطاعم',
    'caterings' => 'مقدمى الطعام',
    'advertisements' => 'الاعلانات',
    'coupons' => 'كوبونات',
    'reservations' => 'الحجز',
    'interests' => 'اهتمامات'

];
