<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class HospitalClinicController extends Controller
{
    public function index(){
        $hospitals = DB::table('hospital_clinic')
            ->join('hospitals', 'hospitals.hospital_id', '=', 'hospital_clinic.hospital_id')
            ->join('clinics', 'clinics.clinic_id', '=', 'hospital_clinic.clinic_id')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->select('clinics.clinic_id as id', 'hospitals.hospital_id',
                'clinic_image as image', 'clinic_phone as phone',
                'clinic_latitude as latitude', 'clinic_longitude as longitude', 'clinic_name as name')
            ->where('language_id', '=', language())
            ->get();

        return view('superAdmin.hospital_clinic.index', compact('hospitals'));
    }

    public function create(){
        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->select('hospitals.hospital_id as id', 'hospital_name as name')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.hospital_clinic.create', compact('hospitals'));
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'clinic_name' => 'required',
            'clinic_phone' => 'required',
            'clinic_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'clinic_description_part' => 'required',
            'clinic_description_full' => 'required',
            'clinic_latitude' => 'required',
            'clinic_longitude' => 'required',
            'hospital_id' => 'required'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        if ($request->hasFile('clinic_image')) {
            $imageName = 'images/clinic/'.time().'.'.$request->clinic_image->getClientOriginalExtension();
            $request->clinic_image->move(public_path('images/clinic'), $imageName);
        } else {
            $imageName = 'images/clinic/avatar_clinic.jpg';
        }

        $clinics = DB::table('clinics')
            ->insertGetId([
                'clinic_phone' => $request->clinic_phone,
                'clinic_image' => $imageName,
                'clinic_latitude' => $request->clinic_latitude,
                'clinic_longitude' => $request->clinic_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('clinic_description')
                ->insert([
                    'clinic_name' => $request->clinic_name[$i],
                    'clinic_description_part' => $request->clinic_description_part[$i],
                    'clinic_description_full' => $request->clinic_description_full[$i],
                    'language_id' => $i,
                    'clinic_id' => $clinics
                ]);
        }

        $hospital_clinic = DB::table('hospital_clinic')->insert([
            'hospital_id' => $request->hospital_id,
            'clinic_id' => $clinics
        ]);

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->select('hospitals.hospital_id as id', 'hospital_name as name')
            ->where('language_id', '=', language())
            ->get();

        $clinics = DB::table('clinics')
            ->join('hospital_clinic', 'hospital_clinic.clinic_id', '=', 'clinics.clinic_id')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->select('clinics.clinic_id as id', 'clinic_image as image', 'clinic_phone as phone',
                'clinic_latitude as latitude', 'clinic_longitude as longitude', 'hospital_id', 'clinic_name as name',
                'clinic_description_part as description_part', 'clinic_description_full as description_full')
            ->where('clinics.clinic_id', '=', $id)
            ->get();

        return view('superAdmin.hospital_clinic.edit', compact('clinics', 'hospitals'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'clinic_name' => 'required',
            'clinic_phone' => 'required',
            'clinic_image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'clinic_description_part' => 'required',
            'clinic_description_full' => 'required',
            'clinic_latitude' => 'required',
            'clinic_longitude' => 'required',
            'hospital_id' => 'required'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        if ($request->hasFile('clinic_image')) {
            $imageName = 'images/clinic'.time().'.'.$request->clinic_image->getClientOriginalExtension();
            $request->clinic_image->move(public_path('images'), $imageName);
        } else {
            $imageName = 'images/hospital/avatar_hospital.png';
        }

        $clinics = DB::table('clinics')
            ->where('clinic_id', '=', $id)
            ->update([
                'clinic_phone' => $request->clinic_phone,
                'clinic_image' => $imageName,
                'clinic_latitude' => $request->clinic_latitude,
                'clinic_longitude' => $request->clinic_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('clinic_description')
                ->where('clinic_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'clinic_name' => $request->clinic_name[$i],
                    'clinic_description_part' => $request->clinic_description_part[$i],
                    'clinic_description_full' => $request->clinic_description_full[$i]
                ]);
        }

        $hospital_clinic = DB::table('hospital_clinic')
            ->where('clinic_id', '=', $id)
            ->update([
                'hospital_id' => $request->hospital_id
            ]);
        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $hospitals = DB::table('clinics')
            ->where('clinic_id', '=', $id)
            ->delete();
        return 1;
    }
}
