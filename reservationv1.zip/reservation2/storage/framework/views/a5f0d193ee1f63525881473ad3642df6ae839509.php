<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php elseif(session()->has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('update_price', $prices[0]->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="price_plan_description_name[1]" class="form-control" placeholder="Enter Name" value="<?php echo e($prices[0]->name); ?>">
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="price_plan_description_name[2]" class="form-control" placeholder="Enter Name" value="<?php echo e($prices[1]->name); ?>">
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="text" name="price" class="form-control" placeholder="Enter Price" value="<?php echo e($prices[0]->price); ?>">
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="price_plan_description_part[1]" class="form-control" placeholder="Enter Description Part" value="<?php echo e($prices[0]->description_part); ?>">
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="price_plan_description_part[2]" class="form-control" placeholder="Enter Description Part" value="<?php echo e($prices[1]->description_part); ?>">
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="price_plan_description_full[1]" class="form-control" placeholder="Enter Description Full"><?php echo e($prices[0]->description_full); ?></textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="price_plan_description_full[2]" class="form-control" placeholder="Enter Description Full"><?php echo e($prices[1]->description_full); ?></textarea>
            </div>
            <div class="form-group">
                <label>Select Catering</label>
                <select class="form-control" name="catering_id">
                    <?php $__currentLoopData = $caterings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catering): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($catering->id); ?>" <?php echo e($prices[0]->catering_id == $catering->id ? 'selected':''); ?>><?php echo e($catering->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/prices/edit.blade.php ENDPATH**/ ?>