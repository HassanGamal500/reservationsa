@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(session()->has('error'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('error')}}
            </div>
        @elseif(session()->has('message'))
            <div class="alert alert-success" role="alert">
                {{session()->get('message')}}
            </div>
        @endif
        <form method="post" action="{{route('update_doctor', $doctors[0]->id)}}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="doctor_detail_name[1]" class="form-control" placeholder="Enter Name English" value="{{$doctors[0]->name}}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="doctor_detail_name[2]" class="form-control" placeholder="Enter Name Arabic" value="{{$doctors[1]->name}}" required>
            </div>
            <div class="form-group">
                <label>Specialization (English)</label>
                <input type="text" name="doctor_detail_specialization[1]" class="form-control" placeholder="Enter Specialization" value="{{$doctors[0]->specialization}}" required>
            </div>
            <div class="form-group">
                <label>Specialization (Arabic)</label>
                <input type="text" name="doctor_detail_specialization[2]" class="form-control" placeholder="Enter Specialization" value="{{$doctors[1]->specialization}}" required>
            </div>
            <div class="form-group">
                <label>Work Hours</label>
                <input type="text" name="doctor_work_hours" class="form-control" placeholder="Enter Work Hours" value="{{$doctors[0]->work_hour}}" required>
            </div>
            <div class="form-group">
                <label>Start</label>
                <input type="time" name="doctor_available_start" class="form-control" placeholder="Enter Start Date" value="{{$doctors[0]->start}}" required>
            </div>
            <div class="form-group">
                <label>End</label>
                <input type="time" name="doctor_available_end" class="form-control" placeholder="Enter End Date" value="{{$doctors[0]->end}}" required>
            </div>
            <div class="form-group">
                <label>Select Clinic</label>
                <select class="form-control" name="clinic_id">
                    @foreach($clinics as $clinic)
                        <option value="{{$clinic->id}}" {{$doctors[0]->clinic_id == $clinic->id ? 'selected':''}}>{{$clinic->name}}</option>
                    @endforeach
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
