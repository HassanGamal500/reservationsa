<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{url('/admin')}}">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Reservation</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item {{request()->is('/admin')?'active':''}}">
        <a class="nav-link" href="{{url('/admin')}}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>{{ trans('admin.dashboard') }}</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <!-- Nav Item - Pages Collapse Menu -->

    <li class="nav-item {{request()->is('admin/users', 'admin/add_user')?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUser" aria-expanded="true" aria-controls="collapseUser">
            <i class="fas fa-fw fa-user"></i>
            <span>{{ trans('admin.users') }}</span>
        </a>
        <div id="collapseUser" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/users')?'active':''}}" href="{{url('/admin/users')}}">All Users</a>
                <a class="collapse-item {{request()->is('admin/add_user')?'active':''}}" href="{{url('admin/add_user')}}">Add User</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/hospitals', 'admin/add_hospital', 'admin/clinic_hospital', 'admin/add_clinic_hospital', 'admin/clinic_doctor')?'active':''}}{{request()->segment(1) == 'admin/edit_hospital', 'admin/edit_clinic_hospital'?'active':''}}{{request()->segment(1) == 'admin/edit_clinic_hospital'?'active':''}}{{request()->segment(1) == 'admin/edit_doctor'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseHospital" aria-expanded="true" aria-controls="collapseHospital">
            <i class="fas fa-fw fa-hospital"></i>
            <span>{{ trans('admin.hospitals') }}</span>
        </a>
        <div id="collapseHospital" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/hospitals')?'active':''}}" href="{{url('admin/hospitals')}}">All Hospitals</a>
                <a class="collapse-item {{request()->is('admin/add_hospital')?'active':''}}" href="{{url('admin/add_hospital')}}">Add Hospital</a>
                <a class="collapse-item {{request()->is('admin/clinic_hospital')?'active':''}}" href="{{url('admin/clinic_hospital')}}">Clinics</a>
                <a class="collapse-item {{request()->is('admin/add_clinic_hospital')?'active':''}}" href="{{url('admin/add_clinic_hospital')}}">Add Clinic</a>
                <a class="collapse-item {{request()->is('admin/clinic_doctor')?'active':''}}" href="{{url('admin/clinic_doctor')}}">Doctors</a>
                <a class="collapse-item {{request()->is('admin/add_doctor')?'active':''}}" href="{{url('admin/add_doctor')}}">Add Doctor</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/clinics', 'admin/add_clinic', 'admin/all_doctor', 'admin/add_doctor_clinic')?'active':''}}{{request()->segment(1) == 'admin/edit_clinic'?'active':''}}{{request()->segment(1) == 'admin/edit_doctor_clinic'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseClinic" aria-expanded="true" aria-controls="collapseClinic">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ trans('admin.clinics') }}</span>
        </a>
        <div id="collapseClinic" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/clinics')?'active':''}}" href="{{url('admin/clinics')}}">All Clinics</a>
                <a class="collapse-item {{request()->is('admin/add_clinic')?'active':''}}" href="{{url('admin/add_clinic')}}">Add Clinic</a>
                <a class="collapse-item {{request()->is('admin/all_doctor')?'active':''}}" href="{{url('admin/all_doctor')}}">All Doctors</a>
                <a class="collapse-item {{request()->is('admin/add_doctor_clinic')?'active':''}}" href="{{url('admin/add_doctor_clinic')}}">Add Doctor</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/restaurants', 'admin/add_restaurant')?'active':''}}{{request()->segment(1) == 'admin/edit_restaurant'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseRestaurant" aria-expanded="true" aria-controls="collapseRestaurant">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ trans('admin.restaurants') }}</span>
        </a>
        <div id="collapseRestaurant" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/restaurants')?'active':''}}" href="{{url('admin/restaurants')}}">All Restaurants</a>
                <a class="collapse-item {{request()->is('admin/add_restaurant')?'active':''}}" href="{{url('admin/add_restaurant')}}">Add Restaurant</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/caterings', 'admin/add_catering', 'admin/prices', 'admin/add_price')?'active':''}}{{request()->segment(1) == 'admin/edit_catering'?'active':''}}{{request()->segment(1) == 'admin/edit_price'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCatering" aria-expanded="true" aria-controls="collapseCatering">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ trans('admin.caterings') }}</span>
        </a>
        <div id="collapseCatering" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/caterings')?'active':''}}" href="{{url('admin/caterings')}}">All Caterings</a>
                <a class="collapse-item {{request()->is('admin/add_catering')?'active':''}}" href="{{url('admin/add_catering')}}">Add Catering</a>
                <a class="collapse-item {{request()->is('admin/prices')?'active':''}}" href="{{url('admin/prices')}}">All Price Plan</a>
                <a class="collapse-item {{request()->is('admin/add_price')?'active':''}}" href="{{url('admin/add_price')}}">Add Price Plan</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/advertisements', 'admin/add_advertisement')?'active':''}}{{request()->segment(1) == 'admin/edit_advertisement'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAd" aria-expanded="true" aria-controls="collapseAd">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ trans('admin.advertisements') }}</span>
        </a>
        <div id="collapseAd" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/advertisements')?'active':''}}" href="{{url('admin/advertisements')}}">All Advertisements</a>
                <a class="collapse-item {{request()->is('admin/add_advertisement')?'active':''}}" href="{{url('admin/add_advertisement')}}">Add Advertisement</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/coupons', 'admin/add_coupon')?'active':''}}{{request()->segment(1) == 'admin/edit_coupon'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCoupon" aria-expanded="true" aria-controls="collapseCoupon">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ trans('admin.coupons') }}</span>
        </a>
        <div id="collapseCoupon" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/coupons')?'active':''}}" href="{{url('admin/coupons')}}">All Coupons</a>
                <a class="collapse-item {{request()->is('admin/add_coupon')?'active':''}}" href="{{url('admin/add_coupon')}}">Add Coupon</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item {{request()->is('admin/interests', 'admin/add_interest')?'active':''}}{{request()->segment(1) == 'admin/edit_interest'?'active':''}}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseInterest" aria-expanded="true" aria-controls="collapseInterest">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ trans('admin.interests') }}</span>
        </a>
        <div id="collapseInterest" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item {{request()->is('admin/interests')?'active':''}}" href="{{url('admin/interests')}}">All Interests</a>
                <a class="collapse-item {{request()->is('admin/add_interest')?'active':''}}" href="{{url('admin/add_interest')}}">Add Interest</a>
            </div>
        </div>
    </li>

{{--    <!-- Nav Item - Pages Collapse Menu -->--}}
{{--    <li class="nav-item {{request()->is('reservations', 'add_coupon')?'active':''}}{{request()->segment(1) == 'edit_coupon'?'active':''}}">--}}
{{--        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseReserve" aria-expanded="true" aria-controls="collapseReserve">--}}
{{--            <i class="fas fa-table"></i>--}}
{{--            <span>{{ trans('admin.reservations') }}</span>--}}
{{--        </a>--}}
{{--        <div id="collapseReserve" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">--}}
{{--            <div class="bg-white py-2 collapse-inner rounded">--}}
{{--                <h6 class="collapse-header">Custom Components:</h6>--}}
{{--                <a class="collapse-item {{request()->is('reservations')?'active':''}}" href="/reservations">Hospitals</a>--}}
{{--                <a class="collapse-item {{request()->is('coupons')?'active':''}}" href="/">Clinics</a>--}}
{{--                <a class="collapse-item {{request()->is('coupons')?'active':''}}" href="/">Restaurants</a>--}}
{{--                <a class="collapse-item {{request()->is('coupons')?'active':''}}" href="/">Caterings</a>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </li>--}}

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
