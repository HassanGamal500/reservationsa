@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(session()->has('error'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('error')}}
            </div>
        @elseif(session()->has('message'))
            <div class="alert alert-success" role="alert">
                {{session()->get('message')}}
            </div>
        @endif
        <form method="post" action="{{route('update_hospital', $hospitals[0]->id)}}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="hospital_name[1]" class="form-control" placeholder="Enter Name" value="{{$hospitals[0]->name}}">
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="hospital_name[2]" class="form-control" placeholder="Enter Name" value="{{$hospitals[1]->name}}">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="hospital_phone" class="form-control" placeholder="Enter Phone" value="{{$hospitals[0]->phone}}">
            </div>
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" name="hospital_image" class="form-control-file">
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="hospital_description_part[1]" class="form-control" placeholder="Enter Description Part" value="{{$hospitals[0]->description_part}}">
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="hospital_description_part[2]" class="form-control" placeholder="Enter Description Part" value="{{$hospitals[1]->description_part}}">
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="hospital_description_full[1]" class="form-control" placeholder="Enter Description Full">{{$hospitals[0]->description_full}}</textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="hospital_description_full[2]" class="form-control" placeholder="Enter Description Full">{{$hospitals[1]->description_full}}</textarea>
            </div>
            <div class="form-group">
                <label>Latitude</label>
                <input type="text" name="hospital_latitude" class="form-control" placeholder="Enter Latitude" value="{{$hospitals[0]->latitude}}">
            </div>
            <div class="form-group">
                <label>Longitude</label>
                <input type="text" name="hospital_longitude" class="form-control" placeholder="Enter Longitude" value="{{$hospitals[0]->longitude}}">
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
