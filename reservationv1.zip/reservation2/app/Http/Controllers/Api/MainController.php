<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Model\Language;
use App\Model\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MainController extends Controller
{
    //
    // tasks
    /*
    public function test(Request $request) {

        if (is_numeric($request->input)) {
            $validator = validator()->make($request->all(), [
                'input' => 'required',
                'password' => 'required'
            ]);

            if ($validator->fails()){

                $response = [
                    'status' => 0,
                    'message' => 'your phone or password is not correct',
                ];
                return response()->json($response);

            }

            $user = User::where('phone', $request->input)->first();

        }


        if (filter_var($request->input, FILTER_VALIDATE_EMAIL)) {
            $validator = validator()->make($request->all(), [
                'input' => 'required|email',
                'password' => 'required'
            ]);

            if ($validator->fails()){

                $response = [
                    'status' => 0,
                    'message' => 'your email or password is not correct',
                ];
                return response()->json($response);

            }

            $user = User::where('email', $request->input)->first();

        }

        if ($user) {

            if (Hash::check($request->password, $user->password)) {

                $response = [
                    'status' => 1,
                    'message' => 'your account is correct',
                    'data' => [
                        'User' => $user
                    ]
                ];
                return response()->json($response);

            } else {

                $response = [
                    'status' => 0,
                    'message' => 'your password is not correct, Try Again',
                ];
                return response()->json($response);

            }

        } else {

            $response = [
                'status' => 0,
                'message' => 'your account is not correct',
            ];
            return response()->json($response);

        }

    }


    public function image(Request $request){

        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users',
            'password' => 'required|confirmed',
            'image' => 'required|image',
            'gender' => 'required'
        ]);

        if ($validator->fails()) {

            $response = [
                'status' => 0,
                'error message' => $validator->errors()
            ];
            return response()->json($response);

        }

        $request->merge(['password' => bcrypt($request->password)]);

        $user = User::create($request->all());

        $imageName = 'images/'.time().'.'.request()->image->getClientOriginalExtension();

        request()->image->move(public_path('images'), $imageName);

        $user->api_token = Str::random(60);

        $user->image = $imageName;

        $user->save();

        $response = [
            'status' => 1,
            'message' => 'success',
            'data' => $user
        ];
        return response()->json($response);

    }

    public function imageTwo(Request $request){

        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users',
            'password' => 'required|confirmed',
            'image' => 'required',
            'gender' => 'required'
        ]);

        if ($validator->fails()) {

            $response = [
                'status' => 0,
                'error message' => $validator->errors()
            ];
            return response()->json($response);

        }

        $user = new User();

        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->gender = $request->gender;
        //$request->merge(['password' => bcrypt($request->password)]);

        $image = $request->image;  // your base64 encoded
        $end = strpos($image, ';');
        $count = $end - 11;
        $extension = substr($image, 11, $count);
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageName = time().'.'.$extension;
        File::put(public_path('images'). '/' . $imageName, base64_decode($image));
        $pathImage = 'images/'.$imageName;

        $user->api_token = Str::random(60);

        $user->image = $pathImage;

        $user->save();

        $response = [
            'status' => 1,
            'message' => 'success',
            'data' => $user
        ];
        return response()->json($response);

    }





//        if ($request->type == 1) {
//            foreach ($notifications as $notification){
//                if ($notification->type == 1 && $notification->type_id == $request->type_id) {
//                    $content = 'hospital hospital hospital hospital ';
//                    $gets = DB::table('hospitals')
//                        ->where('hospitals.hospital_id', '=', $request->type_id)
//                        ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
//                        ->select('hospital_name as name', 'hospital_image as image')
//                        ->get();
//
//                    foreach($gets as $get){
//                        $get->content = $content;
//                        $array[]=$get;
//                    }
//
//                    $response = [
//                        'status' => 1,
//                        'message' => 'successful',
//                        'data' => $array
//                    ];
//
//                } else {
//                    $response = [
//                        'status' => 0,
//                        'message' => 'not found',
//                    ];
//                }
//            }
//        } elseif ($request->type == 2) {
//            foreach ($notifications as $notification){
//                if ($notification->type == 2  && $notification->type_id == $request->type_id) {
//                    $content = 'clinic clinic clinic clinic clinic ';
//                    $gets = DB::table('clinics')
//                        ->where('clinics.clinic_id', '=', $request->type_id)
//                        ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
//                        ->select('clinic_name as name', 'clinic_image as image')
//                        ->get();
//                    foreach($gets as $get){
//                        $get->content = $content;
//                        $array[]=$get;
//                    }
//
//                    $response = [
//                        'status' => 1,
//                        'message' => 'successful',
//                        'data' => $array
//                    ];
//
//                } else {
//                    $response = [
//                        'status' => 0,
//                        'message' => 'not found',
//                    ];
//                }
//            }
//        } elseif ($request->type == 3) {
//            foreach ($notifications as $notification) {
//                if ($notification->type == 3  && $notification->type_id == $request->type_id) {
//                    $content = 'restaurant restaurant restaurant restaurant ';
//                    $gets = DB::table('restaurants')
//                        ->where('restaurants.restaurant_id', '=', $request->type_id)
//                        ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
//                        ->select('restaurant_name as name', 'restaurant_image as image')
//                        ->get();
//                    foreach($gets as $get){
//                        $get->content = $content;
//                        $array[]=$get;
//                    }
//
//                    $response = [
//                        'status' => 1,
//                        'message' => 'successful',
//                        'data' => $array
//                    ];
//
//                } else {
//                    $response = [
//                        'status' => 0,
//                        'message' => 'not found',
//                    ];
//                }
//            }
//        } elseif ($request->type == 4) {
//            foreach ($notifications as $notification) {
//                if ($notification->type == 4  && $notification->type_id == $request->type_id) {
//                    $content = 'catering catering catering catering ';
//                    $gets = DB::table('catering')
//                        ->where('catering.restaurant_id', '=', $request->type_id)
//                        ->join('catering_description', 'restaurant_description.catering_id', '=', 'catering.catering_id')
//                        ->select('catering_name as name', 'catering_image as image')
//                        ->get();
//                    foreach($gets as $get){
//                        $get->content = $content;
//                        $array[]=$get;
//                    }
//
//                    $response = [
//                        'status' => 1,
//                        'message' => 'successful',
//                        'data' => $array
//                    ];
//
//                } else {
//                    $response = [
//                        'status' => 0,
//                        'message' => 'not found',
//                    ];
//                }
//            }
//        } else {
//            $array[] = [
//                'name' => 'Administrator',
//                'image' => '/images/1570432357.png',
//                'content' => 'admin admin admin admin admin admin '
//            ];
//
//            $response = [
//                'status' => 1,
//                'message' => 'successful',
//                'data' => $array
//            ];
//
//        }





//        if ($request->type == 1) {
//            $type = 'hospitals';
//            $type_id = 'hospital_id';
//            $join = 'hospital_description';
//            $image = 'hospital_image';
//            $name = 'hospital_name';
//            $content = 'hospital hospital hospital hospital ';
//        } elseif ($request->type == 2) {
//            $type = 'clinics';
//            $type_id = 'clinic_id';
//            $join = 'clinic_description';
//            $image = 'clinic_image';
//            $name = 'clinic_name';
//            $content = 'clinic clinic clinic clinic clinic ';
//        } elseif ($request->type == 3) {
//            $type = 'restaurants';
//            $type_id = 'restaurant_id';
//            $join = 'restaurant_description';
//            $image = 'restaurant_image';
//            $name = 'restaurant_name';
//            $content = 'restaurant restaurant restaurant restaurant ';
//        } elseif ($request->type == 4) {
//            $type = 'catering';
//            $type_id = 'catering_id';
//            $join = 'catering_description';
//            $image = 'catering_image';
//            $name = 'catering_name';
//            $content = 'catering catering catering catering ';
//        } else {
//            $nameAdmin = 'Administrator';
//            $imageAdmin = '/images/1570432357.png';
//            $contentAdmin = 'admin admin admin admin admin admin ';
//        }
//
//        if ($request->type != 5) {
//            $gets = DB::table('notifications')
//                ->join($type, $type.'.'.$type_id, '=', 'notifications.type_id')
//                ->where($type.'.'.$type_id, '=', $request->type_id)
//                ->join($join, $join.'.'.$type_id, '=', $type.'.'.$type_id)
////                ->join('notifications', 'notifications.type_id', '=', $type.'.'.$type_id)
//                ->select($name.' as name', $image.' as image')
//                ->get();
//            foreach($gets as $get){
//                $get->content = $content;
//                $array[]=$get;
//            }
//        } else {
//            $array[] = [
//                'name' => $nameAdmin,
//                'image' => $imageAdmin,
//                'content' => $contentAdmin
//            ];
//        }



*/

    public function languages() {
        $languages = Language::all();
        return $languages;
    }

    public function page(Request $request) {
        $validator = validator()->make($request->all(), [
            'page_id' => 'required',
            'language_id' => 'required'
        ]);
        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }
        $page = DB::table('pages')
            ->join('page_description', 'page_description.page_id', '=', 'pages.page_id')
//            ->join('languages', 'languages.language_id', '=', 'page_description.language_id')
            ->select('pages.page_id', 'page_slug', 'page_description_name', 'page_description_content', 'language_id')
            ->where('pages.page_id', '=', $request->page_id)
            ->where('language_id', '=', $request->language_id)
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $page
        ];

        return response()->json($response);
    }

    public function advertisements() {
        $ad = DB::table('advertisements')
            ->join('advertisement_description', 'advertisement_description.advertisement_id', '=', 'advertisements.advertisement_id')
            ->select('advertisements.advertisement_id', 'advertisement_image', 'advertisement_description_name', 'advertisement_description_content')
            ->orderBy('advertisements.advertisement_id', 'DESC')
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $ad
        ];

        return response()->json($response);
    }

    public function allHospitals(Request $request) {
        $validator = validator()->make($request->all(), [
//            'hospital_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->where('language_id', '=', $request->language_id)
            ->select('hospitals.hospital_id', 'hospital_image', 'hospital_name', 'hospital_description_part', 'language_id')
            ->get();

        foreach($hospitals as $hospital){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 1)
                ->where('rates.type_id', '=', $hospital->hospital_id)
                ->select('rate_star')
                ->avg('rate_star');
            $hospital->rates=$rates;
            $array[]=$hospital;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function hospital(Request $request) {
        $validator = validator()->make($request->all(), [
            'hospital_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $array = array();

        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
//            ->join('comments', 'comments.type_id', '=', 'hospitals.hospital_id')
//            ->where('comments.type', '=', 1)
//            ->where('comments.type_id', '=', $request->hospital_id)
            ->where('hospitals.hospital_id', '=', $request->hospital_id)
            ->where('language_id', '=', $request->language_id)
            ->select('hospitals.hospital_id', 'hospital_image',
                'hospital_latitude', 'hospital_longitude',
                'hospital_price','hospital_name',
                'hospital_description_part', 'hospital_description_full',
                'language_id')
            ->get();

        foreach($hospitals as $hospital){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 1)
                ->where('rates.type_id', '=', $hospital->hospital_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $hospital->rates=$rates;
            $array[]=$hospital;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function allClinics(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->where('language_id', '=', $request->language_id)
            ->select('clinics.clinic_id', 'clinic_name', 'clinic_image', 'clinic_description_part', 'language_id')
            ->get();

        foreach($clinics as $clinic){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 2)
                ->where('rates.type_id', '=', $clinic->clinic_id)
                ->select('rate_star')
                ->avg('rate_star');
            $clinic->rates=$rates;
            $array[]=$clinic;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function clinic(Request $request) {
        $validator = validator()->make($request->all(), [
            'clinic_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $array = array();

        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->where('clinics.clinic_id', '=', $request->clinic_id)
            ->where('language_id', '=', $request->language_id)
            ->select('clinics.clinic_id', 'clinic_image',
                'clinic_latitude', 'clinic_longitude','clinic_name',
                'clinic_description_part', 'clinic_description_full',
                'language_id')
            ->get();

        foreach($clinics as $clinic){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 2)
                ->where('rates.type_id', '=', $clinic->clinic_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $clinic->rates=$rates;
            $array[]=$clinic;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function allRestaurants(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $restaurants = DB::table('restaurants')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
            ->where('language_id', '=', $request->language_id)
            ->select('restaurants.restaurant_id', 'restaurant_name', 'restaurant_image', 'restaurant_description_part', 'language_id')
            ->get();

        foreach($restaurants as $restaurant){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 3)
                ->where('rates.type_id', '=', $restaurant->restaurant_id)
                ->select('rate_star')
                ->avg('rate_star');
            $restaurant->rates=$rates;
            $array[]=$restaurant;
        }


        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function restaurant(Request $request) {
        $validator = validator()->make($request->all(), [
            'restaurant_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $array = array();

        $restaurants = DB::table('restaurants')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'restaurants.restaurant_id')
            ->where('restaurants.restaurant_id', '=', $request->restaurant_id)
            ->where('language_id', '=', $request->language_id)
            ->select('restaurants.restaurant_id', 'restaurant_image',
                'restaurant_latitude', 'restaurant_longitude','restaurant_name',
                'restaurant_description_part', 'restaurant_description_full',
                'language_id')
            ->get();

        foreach($restaurants as $restaurant){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 3)
                ->where('rates.type_id', '=', $restaurant->restaurant_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $restaurant->rates=$rates;
            $array[]=$restaurant;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function allCatering(Request $request) {
    $validator = validator()->make($request->all(), [
        'language_id' => 'required'
    ]);

    if ($validator->fails()){

        $response = [
            'status' => 0,
            'message' => $validator->errors(),
        ];
        return response()->json($response);

    }

    $caterings = DB::table('catering')
        ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
        ->where('language_id', '=', $request->language_id)
        ->select('catering.catering_id', 'catering_name', 'catering_image', 'catering_description_part', 'language_id')
        ->get();

    foreach($caterings as $catering) {
        $rates = DB::table('rates')
            ->where('rates.type', '=', 4)
            ->where('rates.type_id', '=', $catering->catering_id)
            ->select('rate_star')
            ->avg('rate_star');
        $catering->rates = $rates;
        $array[] = $catering;
    }

    $response = [
        'status' => 1,
        'message' => 'successful',
        'data' => $array
    ];

    return response()->json($response);
}

    public function allPackages(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required',
            'catering_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

        $packages = DB::table('price_plan')
            ->join('price_plan_description', 'price_plan_description.price_plan_id', '=', 'price_plan.price_plan_id')
            ->where('language_id', '=', $request->language_id)
            ->where('catering_id', '=', $request->catering_id)
            ->select('price_plan.price_plan_id', 'price_plan_description_name',
                'price_plan_description_part', 'price_plan.price',
                'language_id', 'catering_id')
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $packages
        ];

        return response()->json($response);
    }

    public function catering(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required',
            'catering_id' => 'required',
            'price_plan_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => $validator->errors(),
            ];
            return response()->json($response);

        }

//        $caterings = DB::table('catering')
//            ->join('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
//            ->join('price_plan', 'price_plan.catering_id', '=', 'catering.catering_id')
//            ->join('price_plan_description', 'price_plan_description.price_plan_id', '=', 'price_plan.price_plan_id')
//            ->where('price_plan_description.language_id', '=', $request->language_id)
//            ->where('price_plan.catering_id', '=', $request->catering_id)
//            ->where('price_plan_description.price_plan_id', '=', $request->price_plan_id)
//            ->select('price_plan_description_name',
//                'price_plan_description_full', 'price_plan.price',
//                'catering_latitude', 'catering_longitude',
//                'price_plan_description.language_id', 'price_plan.catering_id',
//                'price_plan_description.price_plan_id')
//            ->get();

        $caterings = DB::table('catering')
            ->leftJoin('catering_description', 'catering_description.catering_id', '=', 'catering.catering_id')
            ->where('catering.catering_id', '=', $request->catering_id)
            ->where('language_id', '=', $request->language_id)
            ->select('catering.catering_id', 'catering_latitude', 'catering_longitude', 'language_id')
            ->get();

        $packages = DB::table('price_plan')
            ->rightJoin('price_plan_description', 'price_plan_description.price_plan_id', '=', 'price_plan.price_plan_id')
            ->where('language_id', '=', $request->language_id)
            ->where('price_plan.catering_id', '=', $request->catering_id)
            ->where('price_plan_description.price_plan_id', '=', $request->price_plan_id)
            ->select('price_plan.price_plan_id', 'price_plan_description_name',
                'price_plan_description_full', 'price_plan.price',
                'language_id', 'catering_id')
            ->get();


        foreach($caterings as $catering){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 4)
                ->where('rates.type_id', '=', $catering->catering_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $catering->rates = $rates;
            $catering->package = $packages;
            $array[]=$catering;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

}
