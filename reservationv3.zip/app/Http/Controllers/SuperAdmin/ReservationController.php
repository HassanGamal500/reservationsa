<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReservationController extends Controller
{
    public function hospital($id){
        $reservations = DB::table('hospitals')
            ->join('reserve_hospital', 'reserve_hospital.hospital_id', '=', 'hospitals.hospital_id')
            ->join('users', 'users.id', '=', 'reserve_hospital.user_id')
            ->select('reserve_hospital_id as id', 'users.name as name',
                'reserve_hospital_day as day', 'reserve_hospital_hour as hour')
            ->where('hospitals.hospital_id', '=', $id)
            ->get();

        return view('superAdmin.reservations.index', compact('reservations'));
    }

    public function clinic($id){
        $reservations = DB::table('clinics')
            ->join('reserve_clinic', 'reserve_clinic.clinic_id', '=', 'clinics.clinic_id')
            ->join('users', 'users.id', '=', 'reserve_clinic.user_id')
            ->select('reserve_clinic_id as id', 'users.name as name',
                'reserve_clinic_day as day', 'reserve_clinic_time as hour')
            ->where('clinics.clinic_id', '=', $id)
            ->get();

        return view('superAdmin.reservations.index', compact('reservations'));
    }

    public function restaurant($id){
        $reservations = DB::table('restaurants')
            ->join('reserve_restaurant', 'reserve_restaurant.restaurant_id', '=', 'restaurants.restaurant_id')
            ->join('users', 'users.id', '=', 'reserve_restaurant.user_id')
            ->select('reserve_restaurant_id as id', 'users.name as name',
                'reserve_restaurant_day as day', 'reserve_restaurant_time as hour',
                'reserve_restaurant_num_person as num_person')
            ->where('restaurants.restaurant_id', '=', $id)
            ->get();

        return view('superAdmin.reservations.index', compact('reservations'));
    }

    public function catering($id){
        $reservations = DB::table('catering')
            ->join('reserve_catering', 'reserve_catering.catering_id', '=', 'catering.catering_id')
            ->join('users', 'users.id', '=', 'reserve_catering.user_id')
            ->select('reserve_catering_id as id', 'users.name as name',
                'reserve_catering_day as day', 'reserve_catering_time as hour',
                'reserve_catering_num_of_person as num_person')
            ->where('catering.catering_id', '=', $id)
            ->get();

        return view('superAdmin.reservations.index', compact('reservations'));
    }

    public function showReserve($id){
        $reservation = DB::table('reserve_hospital')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'reserve_hospital.hospital_id')
            ->join('users', 'users.id', '=', 'reserve_hospital.user_id')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'reserve_hospital.clinic_id')
            ->join('doctor_detail', 'doctor_detail.doctor_detail_id', '=', 'reserve_hospital.doctor_id')
            ->join('payment_method', 'payment_method.payment_method_id', '=', 'reserve_hospital.reserve_hospital_payment_id')
            ->where([
                ['reserve_hospital_id', '=', $id],
                ['hospital_description.language_id', '=', language()],
                ['clinic_description.language_id', '=', language()],
//                ['payment_method.language_id', '=', language()],
//                ['doctor_detail.language_id', '=', language()]
            ])
            ->select('reserve_hospital_id as id', 'hospital_name', 'clinic_name', 'doctor_detail_name',
                'users.name as name', 'users.phone as phone', 'users.email as email', 'reserve_hospital_day as day',
                'reserve_hospital_hour as hour', 'reserve_hospital_is_insurance as insurance',
                'payment_method_name as payment', 'reserve_hospital_has_file as file',
                'reserve_hospital_notice as notice')
            ->get();

//        dd($reservation);

        return view('superAdmin.reservations.show', compact('reservation'));
    }
}
