<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class ClinicController extends Controller
{
    public function index(){
        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->select('clinics.clinic_id as id', 'clinic_name as name', 'clinic_phone as phone',
                'clinic_image as image', 'clinic_latitude as latitude', 'clinic_longitude as longitude',
                'clinic_description_part as description_part', 'clinic_description_full as description_full')
            ->where('language_id', '=', language())
            ->orderBy('clinics.clinic_id', 'desc')
            ->get();

        foreach ($clinics as $clinic) {
            $numDoctor = DB::table('doctors')
                ->join('clinic_doctor', 'clinic_doctor.doctor_id', '=', 'doctors.doctor_id')
                ->where('clinic_doctor.clinic_id', '=', $clinic->id)
                ->count();

            $clinic->numDoctor = $numDoctor;
        }

        return view('superAdmin.clinics.index', compact('clinics'));
    }

    public function show($id){
        $doctors = DB::table('doctors')
            ->join('doctor_detail', 'doctor_detail.doctor_id', '=', 'doctors.doctor_id')
            ->join('clinic_doctor', 'clinic_doctor.doctor_id', '=', 'doctors.doctor_id')
            ->select('doctors.doctor_id as id', 'doctor_detail_name as name',
                'doctor_detail_specialization as specialization', 'doctor_work_hours as work_hours',
                'doctor_available_start as start', 'doctor_available_end as end')
            ->where('clinic_doctor.clinic_id', '=', $id)
            ->where('language_id', '=', language())
            ->orderBy('doctors.doctor_id', 'desc')
            ->get();

        return view('superAdmin.clinic_doctor.index', compact('doctors'));
    }

    public function create(){
        return view('superAdmin.clinics.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'clinic_name' => 'required',
            'clinic_phone' => 'required',
            'clinic_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'clinic_description_part' => 'required',
            'clinic_description_full' => 'required',
            'clinic_latitude' => 'required',
            'clinic_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

//        if ($request->hasFile('clinic_image')) {
//            $imageName = 'images/clinic/'.time().'.'.$request->clinic_image->getClientOriginalExtension();
//            $request->clinic_image->move(public_path('images/clinic'), $imageName);
//        } else {
//            $imageName = 'images/clinic/avatar_clinic.jpg';
//        }

        $clinics = DB::table('clinics')
            ->insertGetId([
                'clinic_phone' => $request->clinic_phone,
                'clinic_image' => 'images/clinic/avatar_clinic.jpg',
                'clinic_latitude' => $request->clinic_latitude,
                'clinic_longitude' => $request->clinic_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('clinic_description')
                ->insert([
                    'clinic_name' => $request->clinic_name[$i],
                    'clinic_description_part' => $request->clinic_description_part[$i],
                    'clinic_description_full' => $request->clinic_description_full[$i],
                    'language_id' => $i,
                    'clinic_id' => $clinics
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->select('clinics.clinic_id as id', 'clinic_phone as phone',
                'clinic_image as image', 'clinic_latitude as latitude', 'clinic_longitude as longitude',
                'clinic_name as name', 'clinic_description_part as description_part', 'clinic_description_full as description_full')
            ->where('clinics.clinic_id', '=', $id)
            ->get();

        return view('superAdmin.clinics.edit', compact('clinics'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'clinic_name' => 'required',
            'clinic_phone' => 'required',
            'clinic_image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'clinic_description_part' => 'required',
            'clinic_description_full' => 'required',
            'clinic_latitude' => 'required',
            'clinic_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

//        if ($request->hasFile('clinic_image')) {
//            $imageName = 'images/clinic/'.time().'.'.$request->clinic_image->getClientOriginalExtension();
//            $request->clinic_image->move(public_path('images/clinic'), $imageName);
//        } else {
//            $imageName = 'images/clinic/avatar_clinic.jpg';
//        }

        $hospitals = DB::table('clinics')
            ->where('clinic_id', '=', $id)
            ->update([
                'clinic_phone' => $request->clinic_phone,
                'clinic_image' => 'images/clinic/avatar_clinic.jpg',
                'clinic_latitude' => $request->clinic_latitude,
                'clinic_longitude' => $request->clinic_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('clinic_description')
                ->where('clinic_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'clinic_name' => $request->clinic_name[$i],
                    'clinic_description_part' => $request->clinic_description_part[$i],
                    'clinic_description_full' => $request->clinic_description_full[$i],
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $hospitals = DB::table('clinics')
            ->where('clinic_id', '=', $id)
            ->delete();
        return 1;
    }
}
