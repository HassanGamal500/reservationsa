<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class HospitalController extends Controller
{
    public function index(){
        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->select('hospitals.hospital_id as id', 'hospital_name as name',
                'hospital_image as image', 'hospital_phone as phone',
                'hospital_description_part as description_part', 'hospital_description_full as description_full',
                'hospital_latitude as latitude', 'hospital_longitude as longitude')
            ->where('language_id', '=', language())
            ->get();

        return view('superAdmin.hospitals.index', compact('hospitals'));
    }

    public function create(){
        return view('superAdmin.hospitals.create');
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'hospital_name' => 'required',
            'hospital_phone' => 'required',
            'hospital_image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'hospital_description_part' => 'required',
            'hospital_description_full' => 'required',
            'hospital_latitude' => 'required',
            'hospital_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        if ($request->hasFile('hospital_image')) {
            $imageName = 'images/hospital/'.time().'.'.$request->hospital_image->getClientOriginalExtension();
            $request->hospital_image->move(public_path('images/hospital'), $imageName);
        } else {
            $imageName = 'images/hospital/avatar_hospital.png';
        }

        $hospitals = DB::table('hospitals')
            ->insertGetId([
                'hospital_phone' => $request->hospital_phone,
                'hospital_image' => $imageName,
                'hospital_latitude' => $request->hospital_latitude,
                'hospital_longitude' => $request->hospital_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('hospital_description')
                ->insert([
                    'hospital_name' => $request->hospital_name[$i],
                    'hospital_description_part' => $request->hospital_description_part[$i],
                    'hospital_description_full' => $request->hospital_description_full[$i],
                    'language_id' => $i,
                    'hospital_id' => $hospitals
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->select('hospitals.hospital_id as id', 'hospital_image as image', 'hospital_phone as phone',
                'hospital_latitude as latitude', 'hospital_longitude as longitude', 'hospital_name as name',
                'hospital_description_part as description_part', 'hospital_description_full as description_full')
            ->where('hospitals.hospital_id', '=', $id)
            ->get();

        return view('superAdmin.hospitals.edit', compact('hospitals'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'hospital_name' => 'required',
            'hospital_phone' => 'required',
            'hospital_image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'hospital_description_part' => 'required',
            'hospital_description_full' => 'required',
            'hospital_latitude' => 'required',
            'hospital_longitude' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        if ($request->hasFile('hospital_image')) {
            $imageName = 'images/hospital/'.time().'.'.$request->hospital_image->getClientOriginalExtension();
            $request->hospital_image->move(public_path('images/hospital'), $imageName);
        } else {
            $imageName = 'images/hospital/avatar_hospital.png';
        }

        $hospitals = DB::table('hospitals')
            ->where('hospital_id', '=', $id)
            ->update([
                'hospital_phone' => $request->hospital_phone,
                'hospital_image' => $imageName,
                'hospital_latitude' => $request->hospital_latitude,
                'hospital_longitude' => $request->hospital_longitude
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('hospital_description')
                ->where('hospital_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'hospital_name' => $request->hospital_name[$i],
                    'hospital_description_part' => $request->hospital_description_part[$i],
                    'hospital_description_full' => $request->hospital_description_full[$i],
                ]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $hospitals = DB::table('hospitals')
            ->where('hospital_id', '=', $id)
            ->delete();
        return 1;
    }
}
