@extends('common.index')

@section('content')
<!-- Begin Page Content -->


    <div class="container-fluid" id="print_content">
        <div class="row">
            <div class="col-12">

                <!-- Main content -->
                <div class="invoice p-3 mb-3">
                    <!-- title row -->
                    <div class="row">
                        <div class="col-12">
                            <h4>
                                <i class="fas fa-globe"></i> Reservation
                                <small class="float-right">Day: {{$reservation[0]->day}}</small>
                            </h4>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- info row -->
                    <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">

                            <address>
                                <strong>{{$reservation[0]->name}}</strong><br>
                                Phone: {{$reservation[0]->phone}}<br>
                                Email: {{$reservation[0]->email}}
                            </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">

                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                            <b>Hospital:</b> {{$reservation[0]->catering_name}}<br>
                            <b>Order ID:</b> {{$reservation[0]->id}}<br>
                            <b>Payment Due:</b> {{$reservation[0]->payment}}<br>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!-- Table row -->
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Price Plan</th>
                                    <th>Date</th>
                                    <th>Num Person</th>
                                    <th>Coupon Code</th>
                                    <th>Sub Price</th>
                                    <th>{{trans('admin.status')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($reservation as $reserve)
                                <tr>
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$reserve->price_name}}</td>
                                    <td>{{$reserve->hour}}</td>
                                    <td>{{$reserve->numPerson}}</td>
                                    <td>{{$reserve->coupon_code}}</td>
                                    <td>EGP {{$reserve->subPrice}}</td>
                                    <td>{{$reserve->status_name}}</td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <div class="row">
                        <!-- accepted payments column -->
                        <div class="col-6">
                            <p class="lead">Notice:</p>
                            <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                                {{$reservation[0]->notice}}
                            </p>
{{--                            <hr>--}}
{{--                            <button type="button" class="btn btn-primary" disabled>{{trans('admin.status')}}</button> : <button type="button" class="btn btn-success" disabled>{{$reservation[0]->status_name}}</button>--}}
                        </div>
                        <!-- /.col -->
                        <div class="col-6">


                            <div class="table-responsive">
                                <table class="table">
                                    <tr>
                                        <th style="width:50%">Subtotal:</th>
                                        <td>EGP {{$reservation[0]->subPrice}}</td>
                                    </tr>
                                    <tr>
                                        <th>Discount:</th>
                                        <td>%{{$reservation[0]->discount}}</td>
                                    </tr>
                                    <tr>
                                        <th>Total:</th>
                                        <td>EGP {{$reservation[0]->finalPrice}}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!-- this row will not appear when printing -->

                </div>
                <!-- /.invoice -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    <div class="container-fluid">
        <div class="row no-print">
            <div class="col-12">
                <button class="btn btn-primary float-right mr-2" onclick="printDiv('print_content')"><i class="fas fa-print"></i> Print</button>
            </div>
        </div>
    </div>

<!-- /.container-fluid -->
@endsection
