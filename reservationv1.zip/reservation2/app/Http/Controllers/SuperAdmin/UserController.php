<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class UserController extends Controller
{
    public function index(){
        $users = DB::table('users')
            ->select('id', 'name', 'phone', 'email', 'image', 'gender')
            ->get();
        return view('superAdmin.users.index', compact('users'));
    }

    public function create(){
        return view('superAdmin.users.create');
    }

    public function store(Request $request){

        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users|email',
            'password' => 'required',
            'gender' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        if ($request->hasFile('image')) {
            $imageName = 'images/'.time().'.'.$request->image->getClientOriginalExtension();
            $request->image->move(public_path('images'), $imageName);
        } else {
            $imageName = 'images/user/avatar_user.png';
        }

        $users = DB::table('users')
            ->insert([
                'name' => $request->name,
                'phone' => $request->phone,
                'email' => $request->email,
                'password' => bcrypt($request->password),
                'image' => $imageName,
                'gender' => $request->gender
            ]);

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);

    }

    public function edit($id){
        $users = DB::table('users')
            ->select('id', 'name', 'phone', 'email', 'image', 'gender')
            ->where('id', '=', $id)
            ->first();
        return view('superAdmin.users.edit', compact('users'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required|email',
            'password' => 'nullable',
            'gender' => 'nullable',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        $getUser=User::find($id);
        $allPhone = User::where('phone', $request->phone)->where('id', '!=', $id)->first();
        $allEmail = User::where('email', $request->email)->where('id', '!=', $id)->first();

        $users = DB::table('users')
            ->where('id', '=', $id)
            ->update(['name' => $request->name]);

        if ($allPhone) {
            $error = 'This phone has been taken before';
            return Redirect::back()->with('error', $error);
        } else {
            $getUser->phone = $request->phone;
            $getUser->save();
        }

        if ($allEmail) {
            $error = 'This Email has been taken before';
            return Redirect::back()->with('error', $error);
        } else {
            $getUser->email = $request->email;
            $getUser->save();
        }

        if ($request->password) {
            $users = DB::table('users')
                ->where('id', '=', $id)
                ->update(['password' => bcrypt($request->password),]);
        }

        if ($request->hasFile('image')) {
            $imageName = 'images/'.time().'.'.$request->image->getClientOriginalExtension();

            $request->image->move(public_path('images'), $imageName);

            $users = DB::table('users')
                ->where('id', '=', $id)
                ->update(['image' => $imageName]);
        }

        if ($request->gender) {
            $users = DB::table('users')
                ->where('id', '=', $id)
                ->update(['gender' => $request->gender]);
        }

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy(Request $request, $id){
        $users = DB::table('users')
            ->where('id', '=', $id)
            ->delete();
//        return redirect(route('all_users'));
    }

}
