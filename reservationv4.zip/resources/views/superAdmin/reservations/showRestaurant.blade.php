@extends('common.index')

@section('content')
<!-- Begin Page Content -->


    <div class="container-fluid" id="print_content">
        <div class="row">
            <div class="col-12">

                <!-- Main content -->
                <div class="invoice p-3 mb-3">
                    <!-- title row -->
                    <div class="row">
                        <div class="col-12">
                            <h4>
                                <i class="fas fa-globe"></i> Reservation
                                <small class="float-right">Day: {{$reservation[0]->day}}</small>
                            </h4>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- info row -->
                    <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">

                            <address>
                                <strong>{{$reservation[0]->name}}</strong><br>
                                Phone: {{$reservation[0]->phone}}<br>
                                Email: {{$reservation[0]->email}}
                            </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">

                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                            <b>Restaurant:</b> {{$reservation[0]->restaurant_name}}<br>
                            <b>Order ID:</b> {{$reservation[0]->id}}<br>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!-- Table row -->
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Date</th>
                                    <th>Num Person</th>
                                    <th>{{trans('admin.status')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($reservation as $reserve)
                                <tr>
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$reserve->hour}}</td>
                                    <td>{{$reserve->numPerson}}</td>
                                    <td>{{$reserve->status_name}}</td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <div class="row">
                        <!-- accepted payments column -->
                        <div class="col-6">
                            <div class="col-6">
                                <p class="lead">Notice:</p>
                                <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                                    {{$reservation[0]->notice}}
                                </p>
{{--                                <hr>--}}
{{--                                <button type="button" class="btn btn-primary" disabled>{{trans('admin.status')}}</button> : <button type="button" class="btn btn-success" disabled>{{$reservation[0]->status_name}}</button>--}}
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                </div>
                <!-- /.invoice -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
<div class="container-fluid">
    <div class="row no-print">
        <div class="col-12">
            <button class="btn btn-primary float-right mr-2" onclick="printDiv('print_content')"><i class="fas fa-print"></i> Print</button>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
@endsection
