@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <form method="post" action="{{route('store_price')}}" enctype="multipart/form-data">
            @csrf
            @if(session()->has('error'))
                <div class="alert alert-danger" role="alert">
                    {{session()->get('error')}}
                </div>
            @elseif(session()->has('message'))
                <div class="alert alert-success" role="alert">
                    {{session()->get('message')}}
                </div>
            @endif
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="price_plan_description_name[1]" class="form-control" placeholder="Enter Name English" value="{{ old('price_plan_description_name.1') }}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="price_plan_description_name[2]" class="form-control" placeholder="Enter Name Arabic" value="{{ old('price_plan_description_name.2') }}" required>
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="text" name="price" class="form-control" placeholder="Enter Price" value="{{ old('price') }}" required>
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="price_plan_description_part[1]" class="form-control" placeholder="Enter Description Part" value="{{ old('price_plan_description_part.1') }}" required>
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="price_plan_description_part[2]" class="form-control" placeholder="Enter Description Part" value="{{ old('price_plan_description_part.2') }}" required>
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="price_plan_description_full[1]" class="form-control" placeholder="Enter Description Full" required>{{ old('price_plan_description_full.1') }}</textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="price_plan_description_full[2]" class="form-control" placeholder="Enter Description Full" required>{{ old('price_plan_description_full.2') }}</textarea>
            </div>
            <div class="form-group">
                <label>Select Catering</label>
                <select class="form-control" name="catering_id">
                    @foreach($caterings as $catering)
                        <option value="{{$catering->id}}">{{$catering->name}}</option>
                    @endforeach
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
