<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php elseif(session()->has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('update_coupon', $coupons->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="coupon_name" class="form-control" placeholder="Enter Name" value="<?php echo e($coupons->name); ?>" required>
            </div>
            <div class="form-group">
                <label>Discount</label>
                <input type="text" name="coupon_discount" class="form-control" placeholder="Enter Discount" value="<?php echo e($coupons->discount); ?>" required>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/coupons/edit.blade.php ENDPATH**/ ?>