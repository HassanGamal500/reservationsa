<?php

function language(){
    if (session()->get('locale') == 'ar') {
        return 2;
    } else {
        return 1;
    }
}

?>
