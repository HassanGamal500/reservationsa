<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Doctors</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Doctors</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Work Hours</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($doctor->id); ?></td>
                        <td><?php echo e($doctor->name); ?></td>
                        <td><?php echo e($doctor->specialization); ?></td>
                        <td><?php echo e($doctor->work_hours); ?></td>
                        <td><?php echo e($doctor->start); ?></td>
                        <td><?php echo e($doctor->end); ?></td>
                        <td><a class="btn btn-primary btn-circle btn-sm" href="<?php echo e(url(route('edit_doctor', $doctor->id))); ?>"><i class="fas fa-edit"></i></a></td>
                        <td>
                            <button class="alerts btn btn-danger btn-circle btn-sm" data-url="/delete_doctor/" data-id="<?php echo e($doctor->id); ?>"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/clinic_doctor/index.blade.php ENDPATH**/ ?>