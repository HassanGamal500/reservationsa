@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <form method="post" action="{{route('store_clinic')}}" enctype="multipart/form-data">
            @csrf
            @if(session()->has('error'))
                <div class="alert alert-danger" role="alert">
                    {{session()->get('error')}}
                </div>
            @elseif(session()->has('message'))
                <div class="alert alert-success" role="alert">
                    {{session()->get('message')}}
                </div>
            @endif
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="clinic_name[1]" class="form-control" placeholder="Enter Name English" value="{{ old('clinic_name.1') }}" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="clinic_name[2]" class="form-control" placeholder="Enter Name Arabic" value="{{ old('clinic_name.2') }}" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="clinic_phone" class="form-control" placeholder="Enter Phone" value="{{ old('clinic_phone') }}" required>
            </div>
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" name="clinic_image" class="form-control-file">
            </div>
            <div class="form-group">
                <label>Description Part (English)</label>
                <input type="text" name="clinic_description_part[1]" class="form-control" placeholder="Enter Description Part" value="{{ old('clinic_description_part.1') }}" required>
            </div>
            <div class="form-group">
                <label>Description Part (Arabic)</label>
                <input type="text" name="clinic_description_part[2]" class="form-control" placeholder="Enter Description Part" value="{{ old('clinic_description_part.2') }}" required>
            </div>
            <div class="form-group">
                <label>Description Full (English)</label>
                <textarea type="text" name="clinic_description_full[1]" class="form-control" placeholder="Enter Description Full" required>{{ old('clinic_description_full.1') }}</textarea>
            </div>
            <div class="form-group">
                <label>Description Full (Arabic)</label>
                <textarea type="text" name="clinic_description_full[2]" class="form-control" placeholder="Enter Description Full" required>{{ old('clinic_description_full.2') }}</textarea>
            </div>
            <div class="form-group">
                <label>Latitude</label>
                <input type="text" name="clinic_latitude" class="form-control" placeholder="Enter Latitude" value="{{ old('clinic_latitude') }}" required>
            </div>
            <div class="form-group">
                <label>Longitude</label>
                <input type="text" name="clinic_longitude" class="form-control" placeholder="Enter Longitude" value="{{ old('clinic_longitude') }}" required>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
