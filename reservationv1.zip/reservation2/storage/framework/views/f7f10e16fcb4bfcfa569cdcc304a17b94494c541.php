<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <form method="post" action="<?php echo e(route('store_doctor')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php elseif(session()->has('message')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="form-group">
                <label>Name (English)</label>
                <input type="text" name="doctor_detail_name[1]" class="form-control" placeholder="Enter Name English" value="<?php echo e(old('doctor_detail_name.1')); ?>" required>
            </div>
            <div class="form-group">
                <label>Name (Arabic)</label>
                <input type="text" name="doctor_detail_name[2]" class="form-control" placeholder="Enter Name Arabic" value="<?php echo e(old('doctor_detail_name.2')); ?>" required>
            </div>
            <div class="form-group">
                <label>Specialization (English)</label>
                <input type="text" name="doctor_detail_specialization[1]" class="form-control" placeholder="Enter Specialization" value="<?php echo e(old('doctor_detail_specialization.1')); ?>" required>
            </div>
            <div class="form-group">
                <label>Specialization (Arabic)</label>
                <input type="text" name="doctor_detail_specialization[2]" class="form-control" placeholder="Enter Specialization" value="<?php echo e(old('doctor_detail_specialization.2')); ?>" required>
            </div>
            <div class="form-group">
                <label>Work Hours</label>
                <input type="text" name="doctor_work_hours" class="form-control" placeholder="Enter Work Hours" value="<?php echo e(old('doctor_work_hours')); ?>" required>
            </div>
            <div class="form-group">
                <label>Start</label>
                <input type="time" name="doctor_available_start" class="form-control" placeholder="Enter Start Date" value="<?php echo e(old('doctor_available_start')); ?>" required>
            </div>
            <div class="form-group">
                <label>End</label>
                <input type="time" name="doctor_available_end" class="form-control" placeholder="Enter End Date" value="<?php echo e(old('doctor_available_end')); ?>" required>
            </div>
            <div class="form-group">
                <label>Select Clinic</label>
                <select class="form-control" name="clinic_id">
                    <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($clinic->id); ?>"><?php echo e($clinic->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/superAdmin/clinic_doctor/create.blade.php ENDPATH**/ ?>