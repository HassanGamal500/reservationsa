@extends('common.index')

@section('content')
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Hospitals</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Hospitals</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Image</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($hospitals as $hospital)
                    <tr>
                        <td>{{$hospital->id}}</td>
                        <td>{{$hospital->name}}</td>
                        <td>{{$hospital->phone}}</td>
                        <td><img src="http://localhost:8000/{{$hospital->image}}" class="img-thumbnail" style="height: 60px; width: 80px"></td>
                        <td>{{$hospital->latitude}}</td>
                        <td>{{$hospital->longitude}}</td>
                        <td><a class="btn btn-primary btn-circle btn-sm" href="{{url(route('edit_hospital', $hospital->id))}}"><i class="fas fa-edit"></i></a></td>
                        <td>
                            <button class="alerts btn btn-danger btn-circle btn-sm" data-url="/delete_hospital/" data-id="{{ $hospital->id }}"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
@endsection
