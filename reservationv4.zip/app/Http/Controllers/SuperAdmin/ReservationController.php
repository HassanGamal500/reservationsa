<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReservationController extends Controller
{
    public function hospital($id){
        $reservations = DB::table('hospitals')
            ->join('reserve_hospital', 'reserve_hospital.hospital_id', '=', 'hospitals.hospital_id')
            ->join('users', 'users.id', '=', 'reserve_hospital.user_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_hospital.status_id')
            ->select('reserve_hospital_id as id', 'users.name as name', 'status_name',
                'reserve_hospital_day as day', 'reserve_hospital_hour as hour')
            ->where('hospitals.hospital_id', '=', $id)
            ->where('status_description.language_id', '=', language())
            ->get();

        return view('superAdmin.reservations.hospital', compact('reservations'));
    }

    public function clinic($id){
        $reservations = DB::table('clinics')
            ->join('reserve_clinic', 'reserve_clinic.clinic_id', '=', 'clinics.clinic_id')
            ->join('users', 'users.id', '=', 'reserve_clinic.user_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_clinic.status_id')
            ->select('reserve_clinic_id as id', 'users.name as name', 'status_name',
                'reserve_clinic_day as day', 'reserve_clinic_time as hour')
            ->where('clinics.clinic_id', '=', $id)
            ->where('status_description.language_id', '=', language())
            ->get();

        return view('superAdmin.reservations.clinic', compact('reservations'));
    }

    public function restaurant($id){
        $reservations = DB::table('restaurants')
            ->join('reserve_restaurant', 'reserve_restaurant.restaurant_id', '=', 'restaurants.restaurant_id')
            ->join('users', 'users.id', '=', 'reserve_restaurant.user_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_restaurant.status_id')
            ->select('reserve_restaurant_id as id', 'users.name as name', 'status_name',
                'reserve_restaurant_day as day', 'reserve_restaurant_time as hour',
                'reserve_restaurant_num_person as num_person')
            ->where('restaurants.restaurant_id', '=', $id)
            ->where('status_description.language_id', '=', language())
            ->get();

        return view('superAdmin.reservations.restaurant', compact('reservations'));
    }

    public function catering($id){
        $reservations = DB::table('catering')
            ->join('reserve_catering', 'reserve_catering.catering_id', '=', 'catering.catering_id')
            ->join('users', 'users.id', '=', 'reserve_catering.user_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_catering.status_id')
            ->select('reserve_catering_id as id', 'users.name as name', 'status_name',
                'reserve_catering_day as day', 'reserve_catering_time as hour',
                'reserve_catering_num_of_person as num_person')
            ->where('catering.catering_id', '=', $id)
            ->where('status_description.language_id', '=', language())
            ->get();

        return view('superAdmin.reservations.catering', compact('reservations'));
    }

    public function showReserveHospital($id){
        $reservation = DB::table('reserve_hospital')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'reserve_hospital.hospital_id')
            ->join('users', 'users.id', '=', 'reserve_hospital.user_id')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'reserve_hospital.clinic_id')
            ->join('doctor_detail', 'doctor_detail.doctor_id', '=', 'reserve_hospital.doctor_id')
            ->join('payment_description', 'payment_description.payment_method_id', '=', 'reserve_hospital.reserve_hospital_payment_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_hospital.status_id')
            ->where([
                ['reserve_hospital_id', '=', $id],
                ['hospital_description.language_id', '=', language()],
                ['clinic_description.language_id', '=', language()],
                ['payment_description.language_id', '=', language()],
                ['doctor_detail.language_id', '=', language()],
                ['status_description.language_id', '=', language()]
            ])
            ->select('reserve_hospital_id as id', 'hospital_name', 'clinic_name', 'payment_name as payment', 'doctor_detail_name',
                'users.name as name', 'users.phone as phone', 'users.email as email', 'reserve_hospital_day as day', 'status_name',
                'reserve_hospital_hour as hour', 'reserve_hospital_is_insurance as insurance', 'reserve_hospital_has_file as file',
                'reserve_hospital_notice as notice')
            ->get();

        return view('superAdmin.reservations.showHospital', compact('reservation'));
    }

    public function showReserveClinic($id){
        $reservation = DB::table('reserve_clinic')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'reserve_clinic.clinic_id')
            ->join('users', 'users.id', '=', 'reserve_clinic.user_id')
            ->join('doctor_detail', 'doctor_detail.doctor_id', '=', 'reserve_clinic.doctor_id')
            ->join('payment_description', 'payment_description.payment_method_id', '=', 'reserve_clinic.reserve_clinic_payment_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_clinic.status_id')
            ->where([
                ['reserve_clinic_id', '=', $id],
                ['clinic_description.language_id', '=', language()],
                ['payment_description.language_id', '=', language()],
                ['doctor_detail.language_id', '=', language()],
                ['status_description.language_id', '=', language()]
            ])
            ->select('reserve_clinic_id as id', 'clinic_name', 'doctor_detail_name', 'status_name',
                'users.name as name', 'users.phone as phone', 'users.email as email', 'reserve_clinic_day as day',
                'reserve_clinic_time as hour', 'reserve_clinic_is_insurance as insurance',
                'payment_name as payment', 'reserve_clinic_has_file as file',
                'reserve_clinic_notice as notice')
            ->get();

//        dd($reservation);

        return view('superAdmin.reservations.showClinic', compact('reservation'));
    }

    public function showReserveRestaurant($id){
        $reservation = DB::table('reserve_restaurant')
            ->join('restaurant_description', 'restaurant_description.restaurant_id', '=', 'reserve_restaurant.restaurant_id')
            ->join('users', 'users.id', '=', 'reserve_restaurant.user_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_restaurant.status_id')
            ->where([
                ['reserve_restaurant_id', '=', $id],
                ['restaurant_description.language_id', '=', language()],
                ['status_description.language_id', '=', language()]
            ])
            ->select('reserve_restaurant_id as id', 'restaurant_name', 'users.name as name', 'users.phone as phone',
                'users.email as email', 'reserve_restaurant_day as day', 'reserve_restaurant_time as hour', 'status_name',
                'reserve_restaurant_num_person as numPerson', 'reserve_restaurant_notice as notice')
            ->get();

//        dd($reservation);

        return view('superAdmin.reservations.showRestaurant', compact('reservation'));
    }

    public function showReserveCatering($id){
        $reservation = DB::table('reserve_catering')
            ->join('catering_description', 'catering_description.catering_id', '=', 'reserve_catering.catering_id')
            ->join('users', 'users.id', '=', 'reserve_catering.user_id')
            ->join('price_plan_description','price_plan_description.price_plan_id', '=', 'reserve_catering.price_plan_id')
            ->join('payment_description', 'payment_description.payment_method_id', '=', 'reserve_catering.reserve_catering_payment_id')
            ->join('status_description', 'status_description.status_id', '=', 'reserve_catering.status_id')
            ->where([
                ['reserve_catering_id', '=', $id],
                ['catering_description.language_id', '=', language()],
                ['price_plan_description.language_id', '=', language()],
                ['payment_description.language_id', '=', language()],
                ['status_description.language_id', '=', language()]
            ])
            ->select('reserve_catering_id as id', 'catering_name', 'price_plan_description_name as price_name',
                'users.name as name', 'users.phone as phone', 'users.email as email', 'status_name',
                'reserve_catering_day as day', 'reserve_catering_time as hour', 'payment_name as payment',
                'reserve_catering_num_of_person as numPerson', 'reserve_catering_notice as notice',
                'reserve_catering_sub_price as subPrice', 'reserve_catering_coupon_code as coupon_code',
                'reserve_catering_coupon_discount as discount', 'reserve_catering_final_price as finalPrice')
            ->get();

//        dd($reservation);

        return view('superAdmin.reservations.showCatering', compact('reservation'));
    }
}
