<?php

return [

    'dashboard' => 'Dashboard',
    'users' => 'Users',
    'hospitals' => 'Hospitals',
    'clinics' => 'Clinics',
    'restaurants' => 'Restaurants',
    'caterings' => 'Caterings',
    'advertisements' => 'Advertisements',
    'coupons' => 'Coupons',
    'reservations' => 'Reservations',
    'interests' => 'Interests'

];
