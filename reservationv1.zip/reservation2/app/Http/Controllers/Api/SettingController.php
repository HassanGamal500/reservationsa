<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Model\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SettingController extends Controller
{
    public function languages() {
        $languages = Language::all();
        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $languages
        ];
        return response()->json($response);
    }

    public function page(Request $request) {
        $validator = validator()->make($request->all(), [
            'page_id' => 'required',
            'language_id' => 'required'
        ]);
        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }
        $page = DB::table('pages')
            ->join('page_description', 'page_description.page_id', '=', 'pages.page_id')
//            ->join('languages', 'languages.language_id', '=', 'page_description.language_id')
            ->select('pages.page_id', 'page_slug', 'page_description_name', 'page_description_content', 'language_id')
            ->where('pages.page_id', '=', $request->page_id)
            ->where('language_id', '=', $request->language_id)
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $page
        ];

        return response()->json($response);
    }
}
