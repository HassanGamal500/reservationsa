<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
/*    Tests     */
//Route::post('login-test', 'Api\AuthController@test');
//Route::post('image', 'Api\AuthController@image');
//Route::post('image-two', 'Api\AuthController@imageTwo');

//------------------------------
Route::group(['namespace' => 'Api'], function() {

    Route::post('login', 'AuthController@login');
    Route::post('register', 'AuthController@register');
    Route::post('reset_password', 'AuthController@resetPassword');
    Route::post('pin_code', 'AuthController@pinCode');
    Route::post('new_password', 'AuthController@newPassword');
    Route::post('profile', 'AuthController@profile');

    Route::get('languages', 'SettingController@languages');
    Route::post('page', 'SettingController@page');

    Route::post('advertisements', 'AppController@advertisements');
    Route::post('histories', 'AppController@Histories');
    Route::post('notifications', 'AppController@notifications');
    Route::post('images', 'AppController@images');
    Route::post('interests', 'AppController@interests');

    Route::post('all_hospitals', 'HospitalController@allHospitals');
    Route::post('hospital', 'HospitalController@hospital');
    Route::post('hospital_clinic', 'HospitalController@hospital_clinic');
    Route::post('clinic_doctor', 'HospitalController@clinic_doctor');
    Route::post('reserve_hospital', 'HospitalController@reserveHospital');

    Route::post('all_clinics', 'ClinicController@allClinics');
    Route::post('clinic', 'ClinicController@clinic');
    Route::post('reserve_clinic', 'ClinicController@reserveClinic');

    Route::post('all_restaurants', 'RestaurantController@allRestaurants');
    Route::post('restaurant', 'RestaurantController@restaurant');
    Route::post('reserve_restaurant', 'RestaurantController@reserveRestaurant');

    Route::post('all_caterings', 'CateringController@allCatering');
    Route::post('all_packages', 'CateringController@allPackages');
    Route::post('catering', 'CateringController@catering');
    Route::post('coupon', 'CateringController@coupon');
    Route::post('reserve_catering', 'CateringController@reserveCatering');

});


