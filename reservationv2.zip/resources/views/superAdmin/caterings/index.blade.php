@extends('common.index')

@section('content')
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Caterings</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Caterings</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($caterings as $catering)
                    <tr>
                        <td>{{$catering->id}}</td>
                        <td>{{$catering->name}}</td>
                        <td><img src="http://localhost:8000/{{$catering->image}}" class="img-thumbnail" style="height: 60px; width: 80px"></td>
                        <td>{{$catering->latitude}}</td>
                        <td>{{$catering->longitude}}</td>
                        <td><a class="btn btn-primary btn-circle btn-sm" href="{{url(route('edit_catering', $catering->id))}}"><i class="fas fa-edit"></i></a></td>
                        <td>
                            <button class="alerts btn btn-danger btn-circle btn-sm" data-url="/delete_catering/" data-id="{{ $catering->id }}"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
@endsection
