<?php

return [

    'dashboard' => 'لوحة التحكم الرئيسية',
    'users' => 'المستخدمين',
    'hospitals' => 'المستشفيات',
    'clinics' => 'العيادات',
    'restaurants' => 'المطاعم',
    'caterings' => 'مقدمى الطعام',
    'advertisements' => 'الاعلانات',
    'coupons' => 'كوبونات',
    'reservations' => 'الحجز',
    'interests' => 'اهتمامات',
    'all user' => 'كل المستخدمين',
    'add user' => 'أضافة المستخدم',
    'all hospital' => 'كل المستشفيات',
    'all clinic' => 'كل العيادات',
    'all restaurant' => 'كل المطاعم',
    'all catering' => 'كل مقدمى الطعام',
    'all advertisement' => 'كل الاعلانات',
    'all coupon' => 'كل الكوبونات',
    'all interest' => 'كل الاهتمامات',
    'name' => 'الاسم ',
    'phone' => 'الموبايل',
    'email' => 'البريد الالكترونى',
    'image' => 'صوره',
    'gender' => 'الجنس',
    'actions' => 'افعال',
    'numClinic' => 'عدد العيادات',
    'numDoctor' => 'عدد الدكاتره',
    'discount' => 'الخصم',

];
