<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HospitalController extends Controller
{
    public function allHospitals(Request $request) {
        $validator = validator()->make($request->all(), [
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
            ->where('language_id', '=', $request->language_id)
            ->select('hospitals.hospital_id', 'hospital_image', 'hospital_name', 'hospital_description_part', 'language_id')
            ->get();

        foreach($hospitals as $hospital){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 1)
                ->where('rates.type_id', '=', $hospital->hospital_id)
                ->select('rate_star')
                ->avg('rate_star');
            $hospital->rates=$rates;
            $array[]=$hospital;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function hospital(Request $request) {
        $validator = validator()->make($request->all(), [
            'hospital_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){

            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);

        }

        $array = array();

        $hospitals = DB::table('hospitals')
            ->join('hospital_description', 'hospital_description.hospital_id', '=', 'hospitals.hospital_id')
//            ->join('comments', 'comments.type_id', '=', 'hospitals.hospital_id')
//            ->where('comments.type', '=', 1)
//            ->where('comments.type_id', '=', $request->hospital_id)
            ->where('hospitals.hospital_id', '=', $request->hospital_id)
            ->where('language_id', '=', $request->language_id)
            ->select('hospitals.hospital_id', 'hospital_image',
                'hospital_latitude', 'hospital_longitude',
                'hospital_price','hospital_name',
                'hospital_description_part', 'hospital_description_full',
                'language_id')
            ->get();

        foreach($hospitals as $hospital){
            $rates = DB::table('rates')
                ->where('rates.type', '=', 1)
                ->where('rates.type_id', '=', $hospital->hospital_id)
                ->select('rate_id', 'rate_star', 'rate_content', 'user_id')
                ->get();
            $hospital->rates=$rates;
            $array[]=$hospital;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $array
        ];

        return response()->json($response);
    }

    public function hospital_clinic(Request $request) {
        $validator = validator()->make($request->all(), [
            'hospital_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $hospitals = DB::table('hospital_clinic')
            ->join('clinics', 'clinics.clinic_id', '=', 'hospital_clinic.clinic_id')
            ->where('hospital_clinic.hospital_id', '=', $request->hospital_id)
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->where('clinic_description.language_id', '=', $request->language_id)
            ->select('hospital_clinic_id', 'hospital_clinic.hospital_id',
                'hospital_clinic.clinic_id', 'clinics.clinic_id', 'clinic_description.clinic_name')
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $hospitals
        ];

        return response()->json($response);
    }

    public function clinic_doctor(Request $request) {
        $validator = validator()->make($request->all(), [
            'clinic_id' => 'required',
            'language_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $hospitals = DB::table('clinic_doctor')
            ->join('doctors', 'doctors.doctor_id', '=', 'clinic_doctor.doctor_id')
            ->where('clinic_doctor.clinic_id', '=', $request->clinic_id)
            ->join('doctor_detail', 'doctor_detail.doctor_id', '=', 'doctors.doctor_id')
            ->where('doctor_detail.language_id', '=', $request->language_id)
            ->select('clinic_doctor_id', 'clinic_doctor.clinic_id',
                'clinic_doctor.doctor_id', 'doctor_detail.doctor_detail_name')
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $hospitals
        ];

        return response()->json($response);
    }

    public function reserveHospital(Request $request) {
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
            'hospital_id' => 'required',
            'clinic_id' => 'required',
            'doctor_id' => 'required',
            'reserve_hospital_day' => 'required',
            'reserve_hospital_hour' => 'required',
            'reserve_hospital_is_insurance' => 'required',
            'reserve_hospital_payment_id' => 'required',
            'reserve_hospital_has_file' => 'required',
            'reserve_hospital_notice' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => 'Validation Error',
                'data' => $validator->errors()->first(),
            ];
            return response()->json($response);
        }

        $reserve = DB::table('reserve_hospital')->insertGetId($request->all());

//        $notification = DB::table('notifications')->insert([
//            'notification_content' => 'lorem lorem lorem',
//            'type' => 1,
//            'type_id' => $reserve
//        ]);

        $query = DB::table('reserve_hospital')->where('reserve_hospital_id', '=', $reserve)->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $query
        ];
        return response()->json($response);
    }

}
