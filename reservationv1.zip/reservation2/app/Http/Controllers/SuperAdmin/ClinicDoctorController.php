<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class ClinicDoctorController extends Controller
{
    public function index(){
//        $doctors = DB::table('clinic_doctor')
//            ->join('clinics', 'clinics.clinic_id', '=', 'clinic_doctor.clinic_id')
        $doctors = DB::table('doctors')
            ->join('doctor_detail', 'doctor_detail.doctor_id', '=', 'doctors.doctor_id')
            ->select('doctors.doctor_id as id', 'doctor_detail_name as name',
                'doctor_detail_specialization as specialization', 'doctor_work_hours as work_hours',
                'doctor_available_start as start', 'doctor_available_end as end')
            ->where('language_id', '=', language())
            ->get();

        return view('superAdmin.clinic_doctor.index', compact('doctors'));
    }

    public function create(){
        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->select('clinics.clinic_id as id', 'clinic_name as name')
            ->where('language_id', '=', language())
            ->get();
        return view('superAdmin.clinic_doctor.create', compact('clinics'));
    }

    public function store(Request $request){
        $validator = validator()->make($request->all(), [
            'doctor_detail_name' => 'required',
            'doctor_detail_specialization' => 'required',
            'doctor_work_hours' => 'required',
            'doctor_available_start' => 'required',
            'doctor_available_end' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        $doctor = DB::table('doctors')
            ->insertGetId([
                'doctor_work_hours' => $request->doctor_work_hours,
                'doctor_available_start' => $request->doctor_available_start,
                'doctor_available_end' => $request->doctor_available_end
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('doctor_detail')
                ->insert([
                    'doctor_detail_name' => $request->doctor_detail_name[$i],
                    'doctor_detail_specialization' => $request->doctor_detail_specialization[$i],
                    'language_id' => $i,
                    'doctor_id' => $doctor
                ]);
        }

        $clinic_doctor = DB::table('clinic_doctor')->insert([
            'clinic_id' => $request->clinic_id,
            'doctor_id' => $doctor
        ]);

        $message = session()->get('locale') == 'ar' ? 'تم التسجيل بنجاح' : 'Inserted Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function edit($id){
        $clinics = DB::table('clinics')
            ->join('clinic_description', 'clinic_description.clinic_id', '=', 'clinics.clinic_id')
            ->select('clinics.clinic_id as id', 'clinic_name as name')
            ->where('language_id', '=', language())
            ->get();

        $doctors = DB::table('doctors')
            ->leftJoin('doctor_detail', 'doctor_detail.doctor_id', '=', 'doctors.doctor_id')
            ->leftJoin('clinic_doctor', 'clinic_doctor.doctor_id', '=', 'doctors.doctor_id')
            ->select('doctors.doctor_id as id', 'doctor_work_hours as work_hour', 'doctor_available_start as start',
                'doctor_available_end as end', 'clinic_id', 'doctor_detail_name as name', 'doctor_detail_specialization as specialization')
            ->where('doctors.doctor_id', '=', $id)
            ->get();
//        dd($doctors);
        return view('superAdmin.clinic_doctor.edit', compact('clinics', 'doctors'));
    }

    public function update(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'doctor_detail_name' => 'required',
            'doctor_detail_specialization' => 'required',
            'doctor_work_hours' => 'required',
            'doctor_available_start' => 'required',
            'doctor_available_end' => 'required',
            'clinic_id' => 'required'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        $hospitals = DB::table('doctors')
            ->where('doctor_id', '=', $id)
            ->update([
                'doctor_work_hours' => $request->doctor_work_hours,
                'doctor_available_start' => $request->doctor_available_start,
                'doctor_available_end' => $request->doctor_available_end
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('doctor_detail')
                ->where('doctor_id', '=', $id)
                ->where('language_id', '=', $i)
                ->update([
                    'doctor_detail_name' => $request->doctor_detail_name[$i],
                    'doctor_detail_specialization' => $request->doctor_detail_specialization[$i]
                ]);
        }

        $hospital_clinic = DB::table('clinic_doctor')
            ->where('doctor_id', '=', $id)
            ->update([
                'clinic_id' => $request->clinic_id
            ]);

        $message = session()->get('locale') == 'ar' ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroy($id){
        $doctor = DB::table('doctors')
            ->where('doctor_id', '=', $id)
            ->delete();
        return 1;
    }
}
