<!-- Bootstrap core JavaScript--><script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="{{asset('panel/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{asset('panel/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<!-- Core plugin JavaScript-->
<script src="{{asset('panel/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

<!-- Custom scripts for all pages-->
<script src="{{asset('panel/js/sb-admin-2.min.js')}}"></script>

<!-- Page level plugins -->
{{--<script src="{{asset('panel/vendor/chart.js/Chart.min.js')}}"></script>--}}
<script src="{{asset('panel/vendor/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('panel/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>

<!-- Page level custom scripts -->
<script src="{{asset('panel/js/demo/datatables-demo.js')}}"></script>

<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="application/javascript">

    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {

        // $('.nav-item').on('click', function () {
        //     $(this).siblings().removeClass('active');
        //     $(this).toggleClass('active');
        // });

        $('.alerts').on('click', function(e){
            var url = $(this).data("url");
            var id = $(this).data("id");
            e.preventDefault();
            swal({
                title: "Are you sure?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })

            .then((willDelete) => {
                if (willDelete) {
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                    $.ajax({
                        type: 'DELETE',
                        url: url+id,
                        // dataType: 'JSON',
                        data: {id: id},
                        success:function(data){
                            // setInterval(function () {
                            //     $('#dataTable').DataTable().ajax.reload();
                            // }, 2000)
                            location.reload();
                        }
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }
            });
        })

    });


</script>

