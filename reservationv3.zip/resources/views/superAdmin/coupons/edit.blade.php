@extends('common.index')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(session()->has('error'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('error')}}
            </div>
        @elseif(session()->has('message'))
            <div class="alert alert-success" role="alert">
                {{session()->get('message')}}
            </div>
        @endif
        <form method="post" action="{{route('update_coupon', $coupons->id)}}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="coupon_name" class="form-control" placeholder="Enter Name" value="{{$coupons->name}}" required>
            </div>
            <div class="form-group">
                <label>Discount</label>
                <input type="text" name="coupon_discount" class="form-control" placeholder="Enter Discount" value="{{$coupons->discount}}" required>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
            <br><br>
        </form>
    </div>

@endsection
