<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Reservation</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
<?php if(request()->is('/')): ?>
    <li class="nav-item active">
<?php else: ?>
    <li class="nav-item">
<?php endif; ?>
        <a class="nav-link" href="/">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span><?php echo e(trans('admin.dashboard')); ?></span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <!-- Nav Item - Pages Collapse Menu -->

    <li class="nav-item <?php echo e(request()->is('users', 'add_user')?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUser" aria-expanded="true" aria-controls="collapseUser">
            <i class="fas fa-fw fa-user"></i>
            <span><?php echo e(trans('admin.users')); ?></span>
        </a>
        <div id="collapseUser" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('users')?'active':''); ?>" href="/users">All Users</a>
                <a class="collapse-item <?php echo e(request()->is('add_user')?'active':''); ?>" href="/add_user">Add User</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('hospitals', 'add_hospital', 'clinic_hospital', 'add_clinic_hospital', 'clinic_doctor')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_hospital', 'edit_clinic_hospital'?'active':''); ?><?php echo e(request()->segment(1) == 'edit_clinic_hospital'?'active':''); ?><?php echo e(request()->segment(1) == 'edit_doctor'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseHospital" aria-expanded="true" aria-controls="collapseHospital">
            <i class="fas fa-fw fa-hospital"></i>
            <span><?php echo e(trans('admin.hospitals')); ?></span>
        </a>
        <div id="collapseHospital" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('hospitals')?'active':''); ?>" href="/hospitals">All Hospitals</a>
                <a class="collapse-item <?php echo e(request()->is('add_hospital')?'active':''); ?>" href="/add_hospital">Add Hospital</a>
                <a class="collapse-item <?php echo e(request()->is('clinic_hospital')?'active':''); ?>" href="/clinic_hospital">Clinics</a>
                <a class="collapse-item <?php echo e(request()->is('add_clinic_hospital')?'active':''); ?>" href="/add_clinic_hospital">Add Clinic</a>
                <a class="collapse-item <?php echo e(request()->is('clinic_doctor')?'active':''); ?>" href="/clinic_doctor">Doctors</a>
                <a class="collapse-item <?php echo e(request()->is('add_doctor')?'active':''); ?>" href="/add_doctor">Add Doctor</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('clinics', 'add_clinic', 'all_doctor', 'add_doctor_clinic')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_clinic'?'active':''); ?><?php echo e(request()->segment(1) == 'edit_doctor_clinic'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseClinic" aria-expanded="true" aria-controls="collapseClinic">
            <i class="fas fa-fw fa-cog"></i>
            <span><?php echo e(trans('admin.clinics')); ?></span>
        </a>
        <div id="collapseClinic" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('clinics')?'active':''); ?>" href="/clinics">All Clinics</a>
                <a class="collapse-item <?php echo e(request()->is('add_clinic')?'active':''); ?>" href="/add_clinic">Add Clinic</a>
                <a class="collapse-item <?php echo e(request()->is('all_doctor')?'active':''); ?>" href="/all_doctor">All Doctors</a>
                <a class="collapse-item <?php echo e(request()->is('add_doctor_clinic')?'active':''); ?>" href="/add_doctor_clinic">Add Doctor</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('restaurants', 'add_restaurant')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_restaurant'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseRestaurant" aria-expanded="true" aria-controls="collapseRestaurant">
            <i class="fas fa-fw fa-cog"></i>
            <span><?php echo e(trans('admin.restaurants')); ?></span>
        </a>
        <div id="collapseRestaurant" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('restaurants')?'active':''); ?>" href="/restaurants">All Restaurants</a>
                <a class="collapse-item <?php echo e(request()->is('add_restaurant')?'active':''); ?>" href="/add_restaurant">Add Restaurant</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('caterings', 'add_catering', 'prices', 'add_price')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_catering'?'active':''); ?><?php echo e(request()->segment(1) == 'edit_price'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCatering" aria-expanded="true" aria-controls="collapseCatering">
            <i class="fas fa-fw fa-cog"></i>
            <span><?php echo e(trans('admin.caterings')); ?></span>
        </a>
        <div id="collapseCatering" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('caterings')?'active':''); ?>" href="/caterings">All Caterings</a>
                <a class="collapse-item <?php echo e(request()->is('add_catering')?'active':''); ?>" href="/add_catering">Add Catering</a>
                <a class="collapse-item <?php echo e(request()->is('prices')?'active':''); ?>" href="/prices">All Price Plan</a>
                <a class="collapse-item <?php echo e(request()->is('add_price')?'active':''); ?>" href="/add_price">Add Price Plan</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('advertisements', 'add_advertisement')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_advertisement'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAd" aria-expanded="true" aria-controls="collapseAd">
            <i class="fas fa-fw fa-cog"></i>
            <span><?php echo e(trans('admin.advertisements')); ?></span>
        </a>
        <div id="collapseAd" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('advertisements')?'active':''); ?>" href="/advertisements">All Advertisements</a>
                <a class="collapse-item <?php echo e(request()->is('add_advertisement')?'active':''); ?>" href="/add_advertisement">Add Advertisement</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('coupons', 'add_coupon')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_coupon'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCoupon" aria-expanded="true" aria-controls="collapseCoupon">
            <i class="fas fa-fw fa-cog"></i>
            <span><?php echo e(trans('admin.coupons')); ?></span>
        </a>
        <div id="collapseCoupon" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('coupons')?'active':''); ?>" href="/coupons">All Coupons</a>
                <a class="collapse-item <?php echo e(request()->is('add_coupon')?'active':''); ?>" href="/add_coupon">Add Coupon</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('interests', 'add_interest')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_interest'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseInterest" aria-expanded="true" aria-controls="collapseInterest">
            <i class="fas fa-fw fa-cog"></i>
            <span><?php echo e(trans('admin.interests')); ?></span>
        </a>
        <div id="collapseInterest" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('interests')?'active':''); ?>" href="/interests">All Interests</a>
                <a class="collapse-item <?php echo e(request()->is('add_interest')?'active':''); ?>" href="/add_interest">Add Interest</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(request()->is('reservations', 'add_coupon')?'active':''); ?><?php echo e(request()->segment(1) == 'edit_coupon'?'active':''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseReserve" aria-expanded="true" aria-controls="collapseReserve">
            <i class="fas fa-table"></i>
            <span><?php echo e(trans('admin.reservations')); ?></span>
        </a>
        <div id="collapseReserve" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item <?php echo e(request()->is('reservations')?'active':''); ?>" href="/reservations">Hospitals</a>
                <a class="collapse-item <?php echo e(request()->is('coupons')?'active':''); ?>" href="/">Clinics</a>
                <a class="collapse-item <?php echo e(request()->is('coupons')?'active':''); ?>" href="/">Restaurants</a>
                <a class="collapse-item <?php echo e(request()->is('coupons')?'active':''); ?>" href="/">Caterings</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\Users\IronDoT\Desktop\reservation2\resources\views/common/sidebar.blade.php ENDPATH**/ ?>